"""
更新機制（獨立模組，只依賴標準庫，連 FastAPI 壞掉時也能用）

流程：
  上傳 tar.gz / zip
  → 檢查套件（自動找出 main.py 所在層級，不管有沒有多包一層資料夾）
  → 先在暫存區解壓並做語法檢查（有錯就直接拒絕，什麼都不改）
  → 備份目前程式（data/ 永遠不動）
  → 覆蓋檔案
  → requirements.txt 有變才跑 pip install
  → 寫下 pending 狀態 → 自我重啟（os.execv，不依賴 docker 指令）
  → 新程式啟動時：載入成功 → 標記成功；載入失敗 → 自動還原備份再重啟
"""
import hashlib
import json
import os
import py_compile
import shutil
import subprocess
import sys
import tarfile
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("CS_HUB_DATA_DIR", APP_DIR / "data"))
BACKUP_DIR = DATA_DIR / "backups"
TMP_DIR = DATA_DIR / "tmp"
STATE_FILE = DATA_DIR / "update_state.json"
LOG_FILE = DATA_DIR / "logs" / "update.log"
EMERGENCY_KEY_FILE = DATA_DIR / "emergency_key.txt"
PROTECTED = {"data", ".env", "__pycache__", ".git"}
REQUIRED_FILES = {"main.py", "VERSION"}
KEEP_BACKUPS = 10
STARTED_AT = datetime.now()
STARTED_AT_UTC = datetime.utcnow()

for _d in (DATA_DIR, BACKUP_DIR, TMP_DIR, LOG_FILE.parent):
    _d.mkdir(parents=True, exist_ok=True)


class UpdateError(Exception):
    pass


def log(msg: str):
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print("UPDATER", line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def read_log(n=80):
    try:
        lines = LOG_FILE.read_text(encoding="utf-8").splitlines()
        return lines[-n:]
    except Exception:
        return []


def current_version() -> str:
    try:
        return (APP_DIR / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        return "unknown"


def read_state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_state(d: dict):
    STATE_FILE.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def emergency_key() -> str:
    if not EMERGENCY_KEY_FILE.exists():
        import secrets
        EMERGENCY_KEY_FILE.write_text(secrets.token_hex(4), encoding="utf-8")
    return EMERGENCY_KEY_FILE.read_text(encoding="utf-8").strip()


# ---------- 套件檢查 ----------

def _safe_member(name: str) -> bool:
    p = Path(name)
    return not (p.is_absolute() or ".." in p.parts)


def inspect_package(path: Path) -> dict:
    """找出套件裡 main.py 所在的根層，回傳 {version, prefix, files}"""
    names = []
    kind = None
    if zipfile.is_zipfile(path):
        kind = "zip"
        with zipfile.ZipFile(path) as z:
            names = [i.filename for i in z.infolist() if not i.is_dir()]
    else:
        try:
            with tarfile.open(path, "r:*") as t:
                kind = "tar"
                names = [m.name for m in t.getmembers() if m.isfile()]
        except tarfile.TarError:
            raise UpdateError("檔案不是有效的 tar.gz 或 zip")
    names = [n.lstrip("./") for n in names]
    for n in names:
        if not _safe_member(n):
            raise UpdateError(f"套件含有不安全路徑：{n}")
    # 找 main.py，取最淺的那個
    cands = sorted([n for n in names if Path(n).name == "main.py"], key=lambda n: len(Path(n).parts))
    if not cands:
        raise UpdateError("套件裡找不到 main.py（請確認是 CS Hub 的更新檔）")
    prefix = str(Path(cands[0]).parent)
    prefix = "" if prefix == "." else prefix + "/"
    files = [n[len(prefix):] for n in names if n.startswith(prefix)]
    top = {Path(f).parts[0] for f in files}
    missing = REQUIRED_FILES - top
    if missing:
        raise UpdateError(f"套件缺少必要檔案：{', '.join(sorted(missing))}")
    if "data" in top or "data/" in prefix:
        files = [f for f in files if Path(f).parts[0] != "data"]
    return {"kind": kind, "prefix": prefix, "files": files, "version": None, "path": str(path)}


def _extract_to(path: Path, info: dict, dest: Path):
    dest.mkdir(parents=True, exist_ok=True)
    prefix = info["prefix"]
    if info["kind"] == "zip":
        with zipfile.ZipFile(path) as z:
            for i in z.infolist():
                if i.is_dir():
                    continue
                n = i.filename.lstrip("./")
                if not n.startswith(prefix):
                    continue
                rel = n[len(prefix):]
                if not rel or Path(rel).parts[0] in PROTECTED:
                    continue
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(i) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    else:
        with tarfile.open(path, "r:*") as t:
            for m in t.getmembers():
                if not m.isfile():
                    continue
                n = m.name.lstrip("./")
                if not n.startswith(prefix):
                    continue
                rel = n[len(prefix):]
                if not rel or Path(rel).parts[0] in PROTECTED:
                    continue
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                src = t.extractfile(m)
                with open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    v = dest / "VERSION"
    info["version"] = v.read_text(encoding="utf-8").strip() if v.exists() else "unknown"


def syntax_check(folder: Path):
    errors = []
    tmp_pyc = TMP_DIR / "syntax_check"
    tmp_pyc.mkdir(parents=True, exist_ok=True)
    for p in folder.rglob("*.py"):
        if "__pycache__" in p.parts:
            continue
        try:
            py_compile.compile(str(p), doraise=True, cfile=str(tmp_pyc / (p.name + "c")))
        except py_compile.PyCompileError as e:
            errors.append(str(e).strip())
        except Exception as e:  # noqa
            errors.append(f"{p.name}: {e}")
    shutil.rmtree(tmp_pyc, ignore_errors=True)
    if errors:
        raise UpdateError("語法檢查未通過：\n" + "\n".join(errors[:5]))


# ---------- 備份／還原 ----------

def make_backup(tag: str = "") -> Path:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"backup_v{current_version()}_{ts}{('_' + tag) if tag else ''}.tar.gz"
    out = BACKUP_DIR / name
    with tarfile.open(out, "w:gz") as t:
        for item in APP_DIR.iterdir():
            if item.name in PROTECTED or item.name.endswith(".pyc"):
                continue
            t.add(item, arcname=item.name, filter=lambda ti: None if "__pycache__" in ti.name else ti)
    # 只留最近 N 份
    backups = sorted(BACKUP_DIR.glob("backup_*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[KEEP_BACKUPS:]:
        try:
            old.unlink()
        except Exception:
            pass
    return out


def list_backups():
    out = []
    for p in sorted(BACKUP_DIR.glob("backup_*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True):
        st = p.stat()
        out.append({"name": p.name, "size": st.st_size, "time": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S")})
    return out


def restore_backup(name: str):
    path = BACKUP_DIR / Path(name).name
    if not path.exists():
        raise UpdateError("找不到備份檔")
    info = inspect_package(path)
    stage = TMP_DIR / f"restore_{int(time.time())}"
    shutil.rmtree(stage, ignore_errors=True)
    _extract_to(path, info, stage)
    _copy_tree(stage, APP_DIR)
    shutil.rmtree(stage, ignore_errors=True)
    log(f"已還原備份 {name} → 版本 {info['version']}")
    return info["version"]


def _copy_tree(src: Path, dst: Path):
    for p in src.rglob("*"):
        if p.is_dir():
            continue
        rel = p.relative_to(src)
        if rel.parts[0] in PROTECTED:
            continue
        target = dst / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, target)
    # 清掉舊的 pyc，確保載入新程式
    for pyc in dst.rglob("__pycache__"):
        shutil.rmtree(pyc, ignore_errors=True)


def _hash(p: Path):
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ""


# ---------- 主流程 ----------

def apply_update(package: Path, user_name: str = "") -> dict:
    """套用更新；成功回傳資訊，呼叫端負責在回應送出後呼叫 schedule_restart()"""
    from_v = current_version()
    log(f"收到更新檔 {package.name}（{package.stat().st_size} bytes），目前版本 {from_v}，操作者 {user_name}")
    info = inspect_package(package)
    stage = TMP_DIR / f"stage_{int(time.time())}"
    shutil.rmtree(stage, ignore_errors=True)
    try:
        _extract_to(package, info, stage)
        log(f"套件版本 {info['version']}，根層 '{info['prefix'] or '(根目錄)'}'，共 {len(info['files'])} 個檔案")
        syntax_check(stage)
        log("語法檢查通過")
        req_changed = _hash(stage / "requirements.txt") != _hash(APP_DIR / "requirements.txt")
        backup = make_backup("pre_update")
        log(f"已備份至 {backup.name}")
        _copy_tree(stage, APP_DIR)
        log("檔案已覆蓋")
        pip_msg = ""
        if req_changed and (APP_DIR / "requirements.txt").exists():
            pip_msg = run_pip_install()
        write_state({
            "pending_verify": True, "from_version": from_v, "to_version": info["version"],
            "backup": backup.name, "filename": package.name, "user": user_name,
            "applied_at": datetime.now().isoformat(timespec="seconds"), "pip": pip_msg,
        })
        return {"from_version": from_v, "to_version": info["version"], "backup": backup.name,
                "files": len(info["files"]), "pip": pip_msg}
    finally:
        shutil.rmtree(stage, ignore_errors=True)


def run_pip_install() -> str:
    log("requirements.txt 有變更，執行 pip install …")
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-r", str(APP_DIR / "requirements.txt")],
                           capture_output=True, text=True, timeout=600)
        msg = "pip install 完成" if r.returncode == 0 else f"pip install 失敗：{(r.stderr or '')[-400:]}"
    except Exception as e:
        msg = f"pip install 無法執行：{e}"
    log(msg)
    return msg


def restart_now():
    """用同一個指令重新啟動自己：新程式碼會被載入，容器不會停。"""
    log("重新啟動程式 …")
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    # 用「原本的啟動指令」重新執行自己（sys.orig_argv 含 -m uvicorn 等完整參數）
    orig = list(getattr(sys, "orig_argv", []) or [])
    if orig:
        argv = [sys.executable] + orig[1:]
    else:
        a0 = sys.argv[0]
        if a0.endswith("__main__.py"):
            argv = [sys.executable, "-m", Path(a0).parent.name] + sys.argv[1:]
        else:
            argv = [sys.executable] + sys.argv
    os.environ["CS_HUB_RESTARTED"] = "1"
    log("exec: " + " ".join(argv))
    try:
        os.execv(sys.executable, argv)
    except Exception as e:
        log(f"execv 失敗：{e}，改用結束程式讓容器 restart policy 重啟")
        os._exit(3)


def schedule_restart(delay: float = 1.0):
    def _go():
        time.sleep(delay)
        restart_now()
    threading.Thread(target=_go, daemon=True).start()


# ---------- 遠端自動更新 ----------

REMOTE_STATE_FILE = DATA_DIR / "remote_update.json"


def parse_version(v: str):
    out = []
    for part in str(v or "0").strip().lstrip("v").split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def read_remote_state() -> dict:
    try:
        return json.loads(REMOTE_STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_remote_state(d: dict):
    REMOTE_STATE_FILE.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def check_remote(manifest_url: str) -> dict:
    """抓 latest.json：{"version": "0.4.2", "url": "https://.../CS_Hub_v0.4.2.tar.gz", "sha256": "...", "notes": "..."}"""
    import urllib.request
    if not manifest_url:
        raise UpdateError("尚未設定更新來源網址")
    req = urllib.request.Request(manifest_url, headers={"User-Agent": "CS-Hub-Updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = json.loads(r.read().decode("utf-8"))
    if not isinstance(data, dict) or not data.get("version") or not data.get("url"):
        raise UpdateError("latest.json 格式不對（需要 version 與 url）")
    cur = current_version()
    newer = parse_version(data["version"]) > parse_version(cur)
    st = {"checked_at": datetime.now().isoformat(timespec="seconds"), "current": cur, "latest": data["version"],
          "url": data["url"], "sha256": data.get("sha256", ""), "notes": data.get("notes", ""), "available": newer}
    write_remote_state(st)
    log(f"檢查更新：目前 {cur}，遠端 {data['version']}（{'有新版' if newer else '已是最新'}）")
    return st


def download_remote(url: str, sha256: str = "") -> Path:
    import urllib.request
    name = Path(url.split("?")[0]).name or "update.tar.gz"
    if not name.endswith((".tar.gz", ".tgz", ".zip", ".tar")):
        name += ".tar.gz"
    dest = TMP_DIR / f"remote_{int(time.time())}_{name}"
    req = urllib.request.Request(url, headers={"User-Agent": "CS-Hub-Updater"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)
    if sha256:
        got = hashlib.sha256(dest.read_bytes()).hexdigest()
        if got.lower() != sha256.lower():
            dest.unlink(missing_ok=True)
            raise UpdateError("下載檔案的 SHA256 不符，已丟棄")
    log(f"已下載 {name}（{dest.stat().st_size} bytes）")
    return dest


def apply_remote(manifest_url: str, user_name: str = "auto") -> dict:
    """檢查 → 下載 → 套用；呼叫端負責 schedule_restart()"""
    st = check_remote(manifest_url)
    if not st["available"]:
        return {"applied": False, "message": f"已是最新版本 {st['current']}", **st}
    pkg = download_remote(st["url"], st.get("sha256", ""))
    try:
        info = apply_update(pkg, user_name)
    finally:
        pkg.unlink(missing_ok=True)
    st["applied_at"] = datetime.now().isoformat(timespec="seconds")
    st["available"] = False
    write_remote_state(st)
    return {"applied": True, "message": f"已套用 {info['to_version']}，正在重新啟動", **info}


# ---------- 啟動時驗證 ----------

def verify_on_boot(import_ok: bool, error: str = ""):
    """由 main.py 在啟動時呼叫。回傳 'ok' / 'rolled_back' / 'none'"""
    st = read_state()
    if not st.get("pending_verify"):
        return "none"
    if import_ok:
        st.update({"pending_verify": False, "result": "success", "verified_at": datetime.now().isoformat(timespec="seconds")})
        write_state(st)
        log(f"更新成功：{st.get('from_version')} → {st.get('to_version')}")
        return "ok"
    # 載入失敗 → 還原
    log(f"新版本載入失敗：{error[:500]}")
    try:
        v = restore_backup(st["backup"])
        st.update({"pending_verify": False, "result": "rolled_back", "error": error[:1000],
                   "verified_at": datetime.now().isoformat(timespec="seconds"), "restored_version": v})
        write_state(st)
        return "rolled_back"
    except Exception as e:
        log(f"還原失敗：{e}")
        st.update({"pending_verify": False, "result": "failed", "error": f"{error[:500]} / 還原失敗：{e}"})
        write_state(st)
        return "failed"
