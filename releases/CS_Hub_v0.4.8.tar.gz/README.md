# CS Hub v0.4.0
官方 LINE 多帳號 AI 客服工作台。安裝、設定、更新、架構請看《交接文件_v0.4.0.md》。

啟動：`python -m uvicorn main:app --host 0.0.0.0 --port 8500`
更新：登入後 `/admin/update` 上傳 tar.gz / zip。
