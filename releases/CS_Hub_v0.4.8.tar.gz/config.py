"""
CS Hub 全域設定。
所有路徑以 APP_DIR（程式所在資料夾）為基準，與容器內的工作目錄無關。
"""
import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("CS_HUB_DATA_DIR", APP_DIR / "data"))
MEDIA_DIR = DATA_DIR / "media"
BACKUP_DIR = DATA_DIR / "backups"
UPLOAD_TMP_DIR = DATA_DIR / "tmp"
LOG_DIR = DATA_DIR / "logs"

for _d in (DATA_DIR, MEDIA_DIR, BACKUP_DIR, UPLOAD_TMP_DIR, LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)

DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DATA_DIR / 'cs_hub.db'}")

# 更新套件保護：這些檔案／資料夾在套用更新時永遠不會被覆蓋或刪除
PROTECTED_PATHS = {"data", ".env", "__pycache__"}


def read_version() -> str:
    try:
        return (APP_DIR / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        return "unknown"


# 自主權分級（每個帳號 × 每個意圖各自一個等級）
AUTONOMY_OBSERVE = 0   # 只觀察：AI 不回、不寫草稿，直接進人工佇列
AUTONOMY_DRAFT = 1     # 草稿：AI 寫好建議回覆，人工按送出
AUTONOMY_AUTO_REVIEW = 2  # 自動送出，但標記待抽查
AUTONOMY_AUTO = 3      # 完全自動

AUTONOMY_LABELS = {
    AUTONOMY_OBSERVE: "只觀察",
    AUTONOMY_DRAFT: "草稿（人工送出）",
    AUTONOMY_AUTO_REVIEW: "自動送出＋抽查",
    AUTONOMY_AUTO: "完全自動",
}

# 預設意圖清單（可在設定頁增修）
DEFAULT_INTENTS = [
    "訂單查詢", "到貨時間", "售前產品", "售後安裝", "補寄缺件",
    "商品損壞", "未收到貨", "退換貨", "發票帳務", "抱怨", "閒聊問候", "其他",
]

# 意圖對照詞彙（來自實際客服紀錄的常見說法，給 AI 判斷參考）
INTENT_KEYWORDS = {
    "訂單查詢": ["查訂單", "訂單", "單號", "貨運追蹤", "貨運單號", "出貨了嗎", "購買人", "電話"],
    "到貨時間": ["還沒到", "什麼時候到", "到貨", "幾天", "多久會到", "配送"],
    "未收到貨": ["未收到貨", "沒有收到", "沒收到", "東西少送", "少了一箱"],
    "補寄缺件": ["缺零件", "少零件", "少螺絲", "沒附", "補寄", "缺件", "少送"],
    "商品損壞": ["破損", "瑕疵", "壞掉", "刮傷", "凹", "裂"],
    "退換貨": ["退貨", "退款", "退費", "換貨", "取消訂單", "取消", "怎麼處理"],
    "發票帳務": ["發票", "統編", "收據", "對帳"],
    "售後安裝": ["組裝", "安裝", "怎麼裝", "說明書", "影片"],
    "售前產品": ["尺寸", "顏色", "有現貨", "多少錢", "價格", "材質", "承重", "型號", "適合"],
}

# 會進入「案件」流程的意圖
CASE_INTENTS = {"補寄缺件": "reship", "商品損壞": "damage", "未收到貨": "not_received", "退換貨": "return"}

CASE_TYPE_LABELS = {
    "reship": "補寄／缺件",
    "damage": "商品損壞",
    "not_received": "未收到貨",
    "return": "退換貨",
    "other": "其他案件",
}

# 案件需要收集的欄位（AI 釐清流程會照這張表問）
CASE_REQUIRED_FIELDS = {
    "reship": ["order_number", "items", "description", "photo", "address_same"],
    "damage": ["order_number", "items", "description", "photo", "address_same"],
    "not_received": ["order_number", "description"],
    "return": ["order_number", "items", "description", "reason"],
    "other": ["order_number", "description"],
}

CASE_FIELD_LABELS = {
    "order_number": "訂單編號",
    "items": "品項／零件",
    "description": "問題描述",
    "photo": "照片",
    "address_same": "收件地址是否相同",
    "new_address": "新地址",
    "reason": "退換貨原因",
}

CONV_STATUSES = ["ai", "pending", "human", "closed"]
CONV_STATUS_LABELS = {
    "ai": "AI 處理中",
    "pending": "待人工",
    "human": "人工處理中",
    "closed": "已結案",
}

ROLES = ["agent", "manager", "admin"]
ROLE_LABELS = {"agent": "客服", "manager": "主管", "admin": "管理員"}
