"""緊急模式：主程式載入失敗時，只提供更新頁與還原功能"""
import html
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse

import updater


def build_app(error_text: str) -> FastAPI:
    app = FastAPI(title="CS Hub（緊急模式）")

    def page(msg=""):
        backups = "".join(
            f"<li>{b['name']}（{b['time']}）"
            f"<form method='post' action='/admin/emergency/restore' style='display:inline'>"
            f"<input type='hidden' name='name' value='{b['name']}'>"
            f"<input type='password' name='key' placeholder='緊急密碼' required> <button>還原這份</button></form></li>"
            for b in updater.list_backups())
        return f"""<!doctype html><html><head><meta charset="utf-8"><title>CS Hub 緊急模式</title>
<style>body{{font-family:system-ui;max-width:860px;margin:30px auto;padding:0 16px;color:#111}}
.card{{border:1px solid #fca5a5;background:#fef2f2;border-radius:10px;padding:18px;margin-bottom:16px}}
pre{{background:#111;color:#f8f8f8;padding:12px;border-radius:8px;overflow:auto;font-size:12px;max-height:280px}}
button{{background:#dc2626;color:#fff;border:0;padding:8px 14px;border-radius:6px;cursor:pointer}}
input{{padding:6px}}</style></head><body>
<h2>⚠️ CS Hub 緊急模式</h2>
<div class="card"><b>主程式載入失敗，目前版本 {updater.current_version()}。</b><br>
你可以上傳修正後的更新檔，或還原到之前的備份。緊急密碼在 NAS 的 <code>data/emergency_key.txt</code>（正常模式的更新頁也會顯示）。
{('<p style="color:#b91c1c"><b>' + html.escape(msg) + '</b></p>') if msg else ''}</div>
<h3>上傳更新檔</h3>
<form method="post" action="/admin/emergency/update" enctype="multipart/form-data">
<input type="file" name="file" accept=".tar.gz,.tgz,.zip" required>
<input type="password" name="key" placeholder="緊急密碼" required>
<button type="submit">上傳並更新</button></form>
<h3>還原備份</h3><ul>{backups or '<li>（無備份）</li>'}</ul>
<h3>錯誤訊息</h3><pre>{html.escape(error_text)}</pre>
<h3>更新紀錄</h3><pre>{html.escape(chr(10).join(updater.read_log(60)))}</pre>
</body></html>"""

    @app.get("/", response_class=HTMLResponse)
    @app.get("/admin/update", response_class=HTMLResponse)
    @app.get("/workbench", response_class=HTMLResponse)
    def index():
        return page()

    @app.get("/health")
    def health():
        return {"status": "emergency", "version": updater.current_version(), "started_at": updater.STARTED_AT_UTC.isoformat(timespec="seconds") + "Z", "error": error_text[-500:]}

    def check_key(key: str):
        if key != updater.emergency_key():
            raise HTTPException(403, "緊急密碼錯誤")

    @app.post("/admin/emergency/update", response_class=HTMLResponse)
    async def do_update(file: UploadFile = File(...), key: str = Form(...)):
        check_key(key)
        tmp = updater.TMP_DIR / Path(file.filename).name
        tmp.write_bytes(await file.read())
        try:
            info = updater.apply_update(tmp, "emergency")
        except updater.UpdateError as e:
            return page(f"更新被拒絕：{e}")
        except Exception as e:  # noqa
            return page(f"更新失敗：{e}")
        finally:
            tmp.unlink(missing_ok=True)
        updater.schedule_restart(1.0)
        return HTMLResponse(f"<meta charset='utf-8'><h3>已套用 {info['to_version']}，正在重新啟動…</h3>"
                            f"<script>setTimeout(()=>location.href='/admin/update',6000)</script>")

    @app.post("/admin/emergency/restore", response_class=HTMLResponse)
    def do_restore(name: str = Form(...), key: str = Form(...)):
        check_key(key)
        try:
            v = updater.restore_backup(name)
        except Exception as e:  # noqa
            return page(f"還原失敗：{e}")
        updater.write_state({"pending_verify": False, "result": "manual_restore", "to_version": v})
        updater.schedule_restart(1.0)
        return HTMLResponse(f"<meta charset='utf-8'><h3>已還原到 {v}，正在重新啟動…</h3>"
                            f"<script>setTimeout(()=>location.href='/admin/update',6000)</script>")

    return app
