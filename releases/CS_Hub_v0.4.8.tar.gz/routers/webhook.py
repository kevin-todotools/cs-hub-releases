"""
LINE Webhook：每個官方帳號一個網址 /webhook/line/{account_code}
原則：驗簽 → 存檔 → 入列 → 立刻回 200。AI 與回覆都在背景 worker 做。
"""
import asyncio
import base64
import logging
import httpx
from fastapi import APIRouter, Request, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import Account, JSONText
from services.line import verify_signature
from services import convo
from services.worker import wake

log = logging.getLogger("cs_hub.webhook")
router = APIRouter()

MEDIA_TYPES = {"image", "video", "audio", "file"}


@router.post("/line/{account_code}")
async def line_webhook(account_code: str, request: Request, db: Session = Depends(get_db)):
    account = db.query(Account).filter_by(code=account_code).first()
    if not account or not account.enabled:
        raise HTTPException(404, "account not found")

    body = await request.body()
    sig = request.headers.get("X-Line-Signature", "")
    if not account.channel_secret:
        log.warning("帳號 %s 尚未設定 Channel Secret，拒絕 webhook", account_code)
        raise HTTPException(403, "channel secret not configured")
    if not verify_signature(account.channel_secret, body, sig):
        raise HTTPException(403, "bad signature")

    # 影子模式／轉發：原封不動（同樣的 body 與簽章）轉給另一個系統，例如 Omnichat
    forward_task = None
    if account.forward_url:
        forward_task = asyncio.create_task(forward_webhook(account.forward_url, body, sig, account.id, db_url_hint=None))

    try:
        data = await request.json()
    except Exception:
        if forward_task:
            await forward_task
        return {"status": "ok"}

    new_jobs = 0
    for event in data.get("events", []):
        etype = event.get("type")
        source = event.get("source", {})
        user_id = source.get("userId")
        if not user_id or source.get("type") != "user":
            continue  # 群組／聊天室訊息不處理

        customer = convo.get_or_create_customer(db, account, user_id)

        if etype == "follow":
            conv = convo.get_or_open_conversation(db, account, customer)
            convo.add_system_message(db, conv, "客人加入好友")
            _add_tag(customer, "加好友 " + _today())
            customer.blocked = False
            continue
        if etype == "unfollow":
            customer.blocked = True
            continue
        if etype != "message":
            continue

        m = event.get("message", {})
        mtype = m.get("type")
        reply_token = event.get("replyToken")
        conv = convo.get_or_open_conversation(db, account, customer)
        if not JSONText.load(customer.tags, []):
            _add_tag(customer, "首次聯絡 " + _today())

        if mtype == "text":
            msg = convo.add_customer_message(db, conv, m.get("text", ""), "text", m.get("id"), reply_token)
        elif mtype in MEDIA_TYPES:
            label = {"image": "[圖片]", "video": "[影片]", "audio": "[語音]", "file": f"[檔案] {m.get('fileName','')}"}[mtype]
            msg = convo.add_customer_message(db, conv, label, mtype, m.get("id"), reply_token)
            convo.enqueue(db, "media_fetch", {"message_id": msg.id, "account_id": account.id})
        elif mtype == "sticker":
            msg = convo.add_customer_message(db, conv, "[貼圖]", "sticker", m.get("id"), reply_token)
        elif mtype == "location":
            msg = convo.add_customer_message(db, conv, f"[位置] {m.get('address','')}", "location", m.get("id"), reply_token)
        else:
            continue

        # 人工處理中（或 AI 被暫停）就不丟給 AI，只提醒人工
        if conv.status == "human" or conv.ai_paused:
            continue
        if conv.status == "closed":
            conv.status = "ai"
        convo.enqueue(db, "ai_process", {"message_id": msg.id, "conversation_id": conv.id, "account_id": account.id})
        new_jobs += 1

    db.commit()
    wake()
    if forward_task:
        await forward_task          # 等轉發完成再回 200（通常 <1 秒）
    return {"status": "ok"}


FORWARD_HEADERS_SKIP = {"host", "content-length", "connection"}


def _today():
    from services.common import fmt_local
    from datetime import datetime
    return fmt_local(datetime.utcnow(), "%Y-%m-%d")


def _add_tag(customer, tag: str):
    tags = JSONText.load(customer.tags, [])
    if tag not in tags:
        tags.append(tag)
        customer.tags = JSONText.dump(tags)


async def forward_webhook(url: str, body: bytes, signature: str, account_id: str, db_url_hint=None, attempt: int = 1):
    """把 LINE 的原始 webhook 轉給另一個系統；失敗則排背景重試（最多 3 次）"""
    headers = {"Content-Type": "application/json", "X-Line-Signature": signature or "", "User-Agent": "LineBotWebhook/2.0 (via CS Hub)"}
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            r = await c.post(url, content=body, headers=headers)
        if r.status_code >= 300:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
        return True
    except Exception as e:
        log.warning("轉發 webhook 失敗（第 %d 次）：%s", attempt, e)
        if attempt < 3:
            from database import session_scope
            with session_scope() as db:
                convo.enqueue(db, "forward_retry", {"url": url, "body_b64": base64.b64encode(body).decode(), "signature": signature,
                                                    "account_id": account_id, "attempt": attempt + 1})
            wake()
        return False
