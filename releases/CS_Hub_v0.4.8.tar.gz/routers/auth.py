from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

import updater
from database import get_db
from models import User, Session as DbSession, Account, JSONText
from services.auth import (verify_password, hash_password, create_session, require_user, COOKIE_NAME,
                           public_user, SESSION_DAYS)
from services.common import audit, get_all_settings

router = APIRouter()


class LoginIn(BaseModel):
    username: str
    password: str


class ChangePwIn(BaseModel):
    old_password: str = ""
    new_password: str


@router.post("/login")
def login(data: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == data.username.strip()).first()
    if not user or not user.is_active or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "帳號或密碼錯誤")
    s = create_session(db, user, request.headers.get("user-agent", ""))
    if user.role == "agent":        # 客服登入即接單；主管／管理員要自己打開「接單中」
        user.online = True
    db.commit()
    audit(db, user, "login")
    db.commit()
    response.set_cookie(COOKIE_NAME, s.id, max_age=SESSION_DAYS * 86400, httponly=True, samesite="lax")
    return {"ok": True, "user": public_user(user)}


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db), user=Depends(require_user)):
    sid = request.cookies.get(COOKIE_NAME)
    if sid:
        db.query(DbSession).filter(DbSession.id == sid).delete()
    user.online = False
    db.commit()
    response.delete_cookie(COOKIE_NAME)
    return {"ok": True}


@router.get("/me")
def me(db: Session = Depends(get_db), user=Depends(require_user)):
    accounts = db.query(Account).order_by(Account.sort_order, Account.name).all()
    allowed = JSONText.load(user.account_ids, [])
    s = get_all_settings(db)
    return {
        "user": public_user(user),
        "accounts": [{"id": a.id, "code": a.code, "name": a.name, "color": a.color, "enabled": a.enabled, "shadow_mode": bool(a.shadow_mode)}
                     for a in accounts if not allowed or a.id in allowed],
        "settings": {
            "poll_interval_seconds": int(s.get("poll_interval_seconds") or 5),
            "sla_warning_minutes": int(s.get("sla_warning_minutes") or 10),
            "emergency_draft_mode": s.get("emergency_draft_mode") == "1",
            "update_available": (updater.read_remote_state().get("latest") if updater.read_remote_state().get("available") else None) if user.role == "admin" else None,
        },
    }


@router.post("/change-password")
def change_password(data: ChangePwIn, db: Session = Depends(get_db), user=Depends(require_user)):
    if not user.must_change_password and not verify_password(data.old_password, user.password_hash):
        raise HTTPException(400, "舊密碼錯誤")
    if len(data.new_password) < 6:
        raise HTTPException(400, "新密碼至少 6 碼")
    user.password_hash = hash_password(data.new_password)
    user.must_change_password = False
    audit(db, user, "change_password")
    db.commit()
    return {"ok": True}


@router.post("/presence")
def presence(online: bool, db: Session = Depends(get_db), user=Depends(require_user)):
    user.online = online
    db.commit()
    return {"ok": True, "online": online}
