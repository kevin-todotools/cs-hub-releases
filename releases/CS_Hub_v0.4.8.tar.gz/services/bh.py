"""
BH（bvhub 官網派單系統）訂單查詢連接器
對應 BH v1.9.57 的唯讀 API：
  GET {bh_base_url}/api/cs/ping
  GET {bh_base_url}/api/cs/orders?q=<訂單編號 / 手機 / 收件人>&limit=5
  Header: X-API-Key: <BH 系統設定 → 客服系統查單 的金鑰>
回傳每張訂單含：中文狀態、public_status（可直接告訴客人的一句話）、items、shipments、aftersale、internal（內部，不可直說）
"""
import logging
import re
import httpx

log = logging.getLogger("cs_hub.bh")

BV_UID_RE = re.compile(r"\b(\d{10}[A-Z0-9]{6}(?:-\d)?)\b")          # BV 訂單編號：10 數字 + 6 英數
ORDER_NO_RE = re.compile(r"\b([A-Za-z]{0,4}\d{8,20})\b")            # 其他平台單號（純數字長串、字母開頭）
PHONE_RE = re.compile(r"(?<!\d)(09\d{2})[-\s]?(\d{3})[-\s]?(\d{3})(?!\d)")


def extract_order_keys(text: str):
    """從客人訊息抓出可查的鍵：手機（正規化成 09xxxxxxxx）、BV 訂單編號、其他長單號。最多 3 個。"""
    keys = []
    if not text:
        return keys
    for m in PHONE_RE.finditer(text):
        k = "".join(m.groups())
        if k not in keys:
            keys.append(k)
    for m in BV_UID_RE.finditer(text.upper()):
        if m.group(1) not in keys:
            keys.append(m.group(1))
    for m in ORDER_NO_RE.finditer(text):
        k = m.group(1)
        if k not in keys and not PHONE_RE.fullmatch(k):
            keys.append(k)
    return keys[:3]


def _headers(token: str):
    return {"X-API-Key": token or "", "Accept": "application/json"}


async def ping(base_url: str, token: str):
    if not base_url:
        return {"ok": False, "error": "尚未設定 BH 網址"}
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            r = await c.get(f"{base_url.rstrip('/')}/api/cs/ping", headers=_headers(token))
        if r.status_code == 401:
            return {"ok": False, "error": "BH 回 401：金鑰不對（到 BH 系統設定 → 客服系統查單 複製）"}
        if r.status_code == 404:
            return {"ok": False, "error": "BH 回 404：BH 版本太舊（需要 v1.9.57 以上）"}
        if r.status_code != 200:
            return {"ok": False, "error": f"BH 回應 {r.status_code}"}
        return r.json()
    except Exception as e:
        return {"ok": False, "error": f"連不到 BH：{e}"}


async def lookup_orders(base_url: str, token: str, query: str, limit: int = 5):
    """回傳 list[order dict]；失敗回 {"error": ...}；沒設定回 None"""
    if not base_url or not query:
        return None
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(f"{base_url.rstrip('/')}/api/cs/orders", params={"q": query, "limit": limit}, headers=_headers(token))
        if r.status_code == 401:
            return {"error": "BH 金鑰不對"}
        if r.status_code != 200:
            return {"error": f"BH 回應 {r.status_code}"}
        data = r.json()
        if isinstance(data, dict) and "orders" in data:
            return data["orders"]
        return data if isinstance(data, list) else []
    except Exception as e:
        log.warning("BH 查詢失敗: %s", e)
        return {"error": str(e)}


def _items_text(items):
    out = []
    for it in items or []:
        s = f"{it.get('name', '')}"
        if it.get("spec"):
            s += f" {it['spec']}"
        s += f" ×{it.get('qty', 1)}"
        if it.get("preorder"):
            s += f"【預購{'，預計 ' + it['preorder_eta'] if it.get('preorder_eta') else ''}】"
        out.append(s)
    return "、".join(out)


def summarize_orders(data, include_internal: bool = True) -> str:
    """把 BH 回傳變成給 AI 看的精簡文字。public 部分可以告訴客人；internal 部分只能參考、不可直說。"""
    if data is None:
        return ""
    if isinstance(data, dict) and "error" in data:
        return f"（BH 查詢失敗：{data['error']}）"
    if not data:
        return "（BH 查無此訂單）"
    lines = []
    for o in (data if isinstance(data, list) else [data])[:5]:
        if not isinstance(o, dict):
            continue
        lines.append(f"▶ 訂單 {o.get('uid', '')}（{o.get('source', '')}，成立 {o.get('created_at', '')}）")
        lines.append(f"  可告知客人：{o.get('public_status', '')}")
        lines.append(f"  訂單狀態 {o.get('order_status', '')}／付款 {o.get('payment_status', '')}（{o.get('payment_method', '')}）／"
                     f"出貨 {o.get('logistic_status', '')}（{o.get('logistic_method', '')}{'，' + o['cvs_info'] if o.get('cvs_info') else ''}）"
                     f"{'／託運單號 ' + o['logistic_trace_code'] if o.get('logistic_trace_code') else ''}／金額 {int(o.get('total_price') or 0)}")
        lines.append(f"  收件人 {o.get('receiver_name', '')} {o.get('receiver_phone', '')}")
        if o.get("items"):
            lines.append(f"  品項：{_items_text(o['items'])}")
        if o.get("customer_remark"):
            lines.append(f"  客人下單備註：{o['customer_remark']}")
        for sh in o.get("shipments") or []:
            extra = []
            if sh.get("tracking_no"):
                extra.append(f"單號 {sh['tracking_no']}")
            if sh.get("shipped_at"):
                extra.append(f"出貨 {sh['shipped_at']}")
            if sh.get("delivered_at"):
                extra.append(f"配達 {sh['delivered_at']}")
            if sh.get("on_hold"):
                extra.append(f"掛單：{sh.get('hold_reason', '')}")
            if sh.get("alloc_short"):
                extra.append(f"缺貨：{sh['alloc_short']}")
            if sh.get("track_status"):
                extra.append(f"貨況：{sh['track_status']}")
            lines.append(f"  出貨單#{sh.get('id')} {sh.get('kind', '')} {sh.get('status', '')}" + ("（" + "；".join(extra) + "）" if extra else ""))
        for sh in o.get("aftersale") or []:
            lines.append(f"  售後單#{sh.get('id')} {sh.get('kind', '')} {sh.get('status', '')}{'：' + sh['detail'] if sh.get('detail') else ''}")
        fl = o.get("flags") or {}
        warn = []
        if fl.get("unsplit"):
            warn.append("未拆單（多個出貨者，等人工處理）")
        if fl.get("blacklisted"):
            warn.append("黑名單攔下")
        if fl.get("open_refund"):
            warn.append("有折讓／退款待辦")
        if fl.get("open_contact"):
            warn.append(f"有 {fl['open_contact']} 筆聯繫未結案")
        if warn:
            lines.append("  ⚠ " + "；".join(warn))
        if include_internal:
            it = o.get("internal") or {}
            if it.get("manage_note"):
                lines.append(f"  [內部註記，不可直說] {it['manage_note']}")
            if it.get("bv_remark"):
                lines.append(f"  [店家備註，不可直說] {it['bv_remark'][:200]}")
            for c in (it.get("contacts") or [])[:3]:
                lines.append(f"  [聯繫紀錄] {c.get('at', '')} {c.get('method', '')}：{c.get('content', '')}{'→' + c['result'] if c.get('result') else ''}")
            for t in (it.get("timeline") or [])[:4]:
                lines.append(f"  [時間軸] {t.get('at', '')} {t.get('text', '')}")
    return "\n".join(lines)
