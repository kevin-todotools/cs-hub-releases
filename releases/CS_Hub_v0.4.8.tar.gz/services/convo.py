"""對話層的共用邏輯：找／開對話、寫訊息、狀態轉換、工作入列"""
from datetime import datetime
from sqlalchemy.orm import Session
from models import Conversation, Customer, Message, Job, JSONText, Account
from services.common import audit


def enqueue(db: Session, kind: str, payload: dict, run_after: datetime = None):
    job = Job(kind=kind, payload=JSONText.dump(payload), run_after=run_after)
    db.add(job)
    return job


def get_or_create_customer(db: Session, account: Account, line_user_id: str) -> Customer:
    cust = db.query(Customer).filter_by(account_id=account.id, line_user_id=line_user_id).first()
    if not cust:
        cust = Customer(account_id=account.id, line_user_id=line_user_id)
        db.add(cust)
        db.flush()
        enqueue(db, "profile_fetch", {"customer_id": cust.id})
    return cust


def get_open_conversation(db: Session, customer: Customer) -> Conversation:
    return (db.query(Conversation)
            .filter(Conversation.customer_id == customer.id, Conversation.status != "closed")
            .order_by(Conversation.created_at.desc()).first())


def get_or_open_conversation(db: Session, account: Account, customer: Customer) -> Conversation:
    conv = get_open_conversation(db, customer)
    if conv:
        return conv
    last_closed = (db.query(Conversation).filter(Conversation.customer_id == customer.id)
                   .order_by(Conversation.created_at.desc()).first())
    conv = Conversation(account_id=account.id, customer_id=customer.id, status="ai",
                        reopened_from=last_closed.id if last_closed else None)
    db.add(conv)
    db.flush()
    return conv


def add_customer_message(db: Session, conv: Conversation, content: str, msg_type="text",
                         line_message_id=None, reply_token=None) -> Message:
    now = datetime.utcnow()
    msg = Message(conversation_id=conv.id, role="customer", content=content or "", msg_type=msg_type,
                  line_message_id=line_message_id, reply_token=reply_token,
                  reply_token_at=now if reply_token else None, delivery="received")
    db.add(msg)
    conv.last_message_at = now
    conv.last_customer_message_at = now
    conv.unread_count = (conv.unread_count or 0) + 1
    if not conv.waiting_since:
        conv.waiting_since = now
    db.flush()
    return msg


def add_outbound_message(db: Session, conv: Conversation, role: str, content: str, sender_user_id=None,
                         ai_meta=None, delivery="pending") -> Message:
    now = datetime.utcnow()
    msg = Message(conversation_id=conv.id, role=role, content=content, sender_user_id=sender_user_id,
                  ai_meta=JSONText.dump(ai_meta) if isinstance(ai_meta, dict) else ai_meta, delivery=delivery)
    db.add(msg)
    if role in ("ai", "agent"):
        conv.last_message_at = now
        conv.last_agent_message_at = now
        if conv.waiting_since and conv.first_response_seconds is None:
            conv.first_response_seconds = int((now - conv.waiting_since).total_seconds())
        conv.waiting_since = None
        conv.unread_count = 0
    db.flush()
    return msg


def add_system_message(db: Session, conv: Conversation, content: str) -> Message:
    msg = Message(conversation_id=conv.id, role="system", content=content, delivery="n/a")
    db.add(msg)
    db.flush()
    return msg


def set_status(db: Session, conv: Conversation, status: str, user=None, note: str = None):
    old = conv.status
    conv.status = status
    if status == "closed":
        conv.closed_at = datetime.utcnow()
        conv.closed_by = getattr(user, "display_name", None) or (user if isinstance(user, str) else "system")
        conv.waiting_since = None
        conv.unread_count = 0
    if status in ("human", "pending"):
        conv.human_touched = True
    if status == "human":
        conv.ai_paused = True
    if status == "ai":
        conv.ai_paused = False
        conv.assignee_id = None
    if old != status:
        who = getattr(user, "display_name", None) or (user if isinstance(user, str) else "系統")
        add_system_message(db, conv, note or f"{who} 將狀態從「{old}」改為「{status}」")
        audit(db, user, "conv.status", "conversation", conv.id, {"from": old, "to": status})


def assign(db: Session, conv: Conversation, assignee_id, user=None, note=None):
    from models import User
    conv.assignee_id = assignee_id
    if assignee_id:
        conv.human_touched = True
        target = db.get(User, assignee_id)
        name = target.display_name if target else assignee_id
        who = getattr(user, "display_name", None) or "系統"
        add_system_message(db, conv, note or f"{who} 指派給 {name}")
        if conv.status in ("ai", "pending"):
            conv.status = "human"
            conv.ai_paused = True
    audit(db, user, "conv.assign", "conversation", conv.id, {"assignee_id": assignee_id})


def pick_auto_assignee(db: Session, account_id: str):
    """簡單輪詢：在線、可處理此帳號、目前手上對話最少的人"""
    from models import User
    from sqlalchemy import func
    users = db.query(User).filter(User.is_active == True, User.online == True).all()  # noqa
    cands = [u for u in users if not JSONText.load(u.account_ids, []) or account_id in JSONText.load(u.account_ids, [])]
    if not cands:
        return None
    loads = dict(db.query(Conversation.assignee_id, func.count(Conversation.id))
                 .filter(Conversation.status == "human", Conversation.assignee_id.isnot(None))
                 .group_by(Conversation.assignee_id).all())
    cands.sort(key=lambda u: loads.get(u.id, 0))
    return cands[0]
