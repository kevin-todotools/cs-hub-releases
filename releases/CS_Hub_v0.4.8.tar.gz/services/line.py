"""LINE Messaging API 封裝"""
import base64
import hashlib
import hmac
import logging
import httpx

log = logging.getLogger("cs_hub.line")

API = "https://api.line.me/v2/bot"
DATA_API = "https://api-data.line.me/v2/bot"
REPLY_TOKEN_SAFE_SECONDS = 45   # reply token 官方約一分鐘有效；超過這個秒數就改用 push


def verify_signature(channel_secret: str, body: bytes, signature: str) -> bool:
    if not channel_secret:
        return False
    mac = hmac.new(channel_secret.encode("utf-8"), body, hashlib.sha256).digest()
    expected = base64.b64encode(mac).decode()
    return hmac.compare_digest(expected, signature or "")


def _headers(token: str):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _messages(texts, quick_labels=None):
    msgs = [{"type": "text", "text": t[:5000]} for t in texts[:5]]
    if quick_labels and msgs:
        msgs[-1]["quickReply"] = {"items": [{"type": "action", "action": {"type": "message", "label": l[:20], "text": l[:20]}}
                                           for l in quick_labels[:13]]}
    return msgs


async def reply_message(token: str, reply_token: str, texts, quick_labels=None):
    if isinstance(texts, str):
        texts = [texts]
    payload = {"replyToken": reply_token, "messages": _messages(texts, quick_labels)}
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.post(f"{API}/message/reply", json=payload, headers=_headers(token))
    return r.status_code, r.text


async def push_message(token: str, to: str, texts, quick_labels=None):
    if isinstance(texts, str):
        texts = [texts]
    payload = {"to": to, "messages": _messages(texts, quick_labels)}
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.post(f"{API}/message/push", json=payload, headers=_headers(token))
    return r.status_code, r.text


async def get_profile(token: str, user_id: str):
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(f"{API}/profile/{user_id}", headers=_headers(token))
    if r.status_code == 200:
        return r.json()
    return None


async def get_content(token: str, message_id: str):
    """下載圖片／影片／音訊內容，回傳 (bytes, content_type)"""
    async with httpx.AsyncClient(timeout=60) as c:
        r = await c.get(f"{DATA_API}/message/{message_id}/content", headers={"Authorization": f"Bearer {token}"})
    if r.status_code == 200:
        return r.content, r.headers.get("content-type", "application/octet-stream")
    return None, None


async def get_quota(token: str):
    """本月訊息配額（push 用量監控）"""
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            q = await c.get(f"{API}/message/quota", headers=_headers(token))
            u = await c.get(f"{API}/message/quota/consumption", headers=_headers(token))
        return {"quota": q.json() if q.status_code == 200 else None,
                "used": u.json().get("totalUsage") if u.status_code == 200 else None}
    except Exception as e:
        return {"error": str(e)}
