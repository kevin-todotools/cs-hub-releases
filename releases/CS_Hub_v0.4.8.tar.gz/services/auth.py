"""登入／權限：cookie session，密碼用 PBKDF2（不需額外套件）"""
import hashlib
import os
import secrets
from datetime import datetime, timedelta
from fastapi import Request, HTTPException, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import User, Session as DbSession, JSONText

COOKIE_NAME = "cs_hub_session"
SESSION_DAYS = 14
ROLE_RANK = {"agent": 1, "manager": 2, "admin": 3}


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000)
    return f"pbkdf2${salt}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, salt, hexdk = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120_000)
        return secrets.compare_digest(dk.hex(), hexdk)
    except Exception:
        return False


def create_session(db: Session, user: User, user_agent: str = "") -> DbSession:
    s = DbSession(user_id=user.id, expires_at=datetime.utcnow() + timedelta(days=SESSION_DAYS),
                  user_agent=(user_agent or "")[:200])
    db.add(s)
    db.commit()
    return s


def get_current_user_optional(request: Request, db: Session = Depends(get_db)):
    sid = request.cookies.get(COOKIE_NAME)
    if not sid:
        return None
    s = db.get(DbSession, sid)
    if not s or (s.expires_at and s.expires_at < datetime.utcnow()):
        return None
    user = db.get(User, s.user_id)
    if not user or not user.is_active:
        return None
    # 更新 last_seen（每分鐘最多一次，避免狂寫）
    if not user.last_seen_at or (datetime.utcnow() - user.last_seen_at).total_seconds() > 60:
        user.last_seen_at = datetime.utcnow()
        db.commit()
    return user


def require_user(user=Depends(get_current_user_optional)):
    if not user:
        raise HTTPException(401, "請先登入")
    return user


def require_role(min_role: str):
    def dep(user=Depends(require_user)):
        if ROLE_RANK.get(user.role, 0) < ROLE_RANK[min_role]:
            raise HTTPException(403, "權限不足")
        return user
    return dep


require_manager = require_role("manager")
require_admin = require_role("admin")


def user_account_ids(user: User):
    """回傳使用者可處理的帳號 id 清單；空清單 = 全部"""
    return JSONText.load(user.account_ids, [])


def user_can_access_account(user: User, account_id: str) -> bool:
    ids = user_account_ids(user)
    return not ids or account_id in ids


def ensure_default_admin(db: Session):
    if db.query(User).count() == 0:
        pw = os.getenv("CS_HUB_ADMIN_PASSWORD", "admin1234")
        db.add(User(username="admin", display_name="管理員", password_hash=hash_password(pw),
                    role="admin", must_change_password=True))
        db.commit()
        return True
    return False


def public_user(u: User) -> dict:
    return {
        "id": u.id, "username": u.username, "display_name": u.display_name, "role": u.role,
        "is_active": u.is_active, "online": u.online, "account_ids": JSONText.load(u.account_ids, []),
        "must_change_password": u.must_change_password,
        "last_seen_at": u.last_seen_at.isoformat() if u.last_seen_at else None,
    }
