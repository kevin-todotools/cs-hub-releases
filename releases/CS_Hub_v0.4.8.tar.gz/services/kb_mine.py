"""
知識萃取：讀客服實際回覆的對話 → AI 整理成「待確認知識」→ 主管確認後進知識庫

來源：
  1. CS Hub 自己的對話（有人工回覆的，kb_mined=False）
  2. 匯入的對話紀錄（TranscriptConv，例如從 Omnichat 匯出的）
流程：
  mine_batch()  每批最多 BATCH 段對話 → Claude 回 JSON 候選清單（含與現有知識的關係：new / duplicate / conflict）
  discuss()     主管在待確認卡片用對話方式跟 AI 討論，AI 可提出修訂版
"""
import csv
import io
import json
import logging
import re
from datetime import datetime

from sqlalchemy.orm import Session

from models import (Conversation, Message, Account, KnowledgeNote, KnowledgeCandidate, TranscriptImport, TranscriptConv,
                    AiUsage, JSONText, gen_id)
from services.common import get_all_settings
from services import ai as ai_svc

log = logging.getLogger("cs_hub.kb_mine")
BATCH = 8
MAX_CHARS_PER_CONV = 2500


# ---------- 匯入解析 ----------

def _role_of(s: str):
    s = (s or "").strip().lower()
    if not s:
        return None
    if any(k in s for k in ("客服", "agent", "operator", "staff", "店家", "官方", "小編", "bot", "機器人", "out", "sent", "發送", "回覆", "我方", "brand")):
        return "agent"
    if any(k in s for k in ("客人", "客戶", "顧客", "customer", "user", "member", "in", "received", "收到", "粉絲", "好友")):
        return "customer"
    return None


def parse_transcripts(text: str, filename: str = "") -> list:
    """回傳 [{external_id, customer_name, messages:[{role,text,at}]}]
    支援：JSON（陣列，每段 {id?, name?, messages:[{role|sender, text|content, at?}]}）、CSV（自動猜欄位）、純文字（客人：／客服： 逐行，空行或 --- 分段）"""
    text = text.lstrip("﻿").strip()
    if not text:
        return []
    if text.startswith("[") or text.startswith("{"):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                data = data.get("conversations") or data.get("items") or [data]
            out = []
            for i, c in enumerate(data):
                msgs = []
                for m in c.get("messages") or []:
                    role = _role_of(str(m.get("role") or m.get("sender") or m.get("direction") or ""))
                    t = (m.get("text") or m.get("content") or m.get("message") or "").strip()
                    if role and t:
                        msgs.append({"role": role, "text": t, "at": str(m.get("at") or m.get("time") or m.get("created_at") or "")})
                if msgs:
                    out.append({"external_id": str(c.get("id") or c.get("conversation_id") or i), "customer_name": str(c.get("name") or c.get("customer") or ""), "messages": msgs})
            return out
        except Exception:
            pass
    if filename.lower().endswith(".csv") or ("," in text.splitlines()[0] and len(text.splitlines()) > 1 and "：" not in text.splitlines()[0]):
        rows = list(csv.reader(io.StringIO(text)))
        if len(rows) >= 2:
            head = [h.strip().lower() for h in rows[0]]

            def find(*keys):
                for i, h in enumerate(head):
                    if any(k in h for k in keys):
                        return i
                return None
            ci = find("conversation", "對話", "會話", "thread", "session", "chat id", "customer id", "顧客id", "用戶id", "userid", "user id", "粉絲")
            ri = find("方向", "direction", "sender", "發送", "角色", "role", "type", "來源", "from")
            ti = find("內容", "message", "text", "訊息", "content", "body")
            ai = find("時間", "time", "date", "at", "日期")
            ni = find("name", "姓名", "名稱", "暱稱")
            if ti is not None:
                groups, order = {}, []
                for r in rows[1:]:
                    if len(r) <= ti:
                        continue
                    key = r[ci] if ci is not None and ci < len(r) else "all"
                    role = _role_of(r[ri]) if ri is not None and ri < len(r) else "customer"
                    t = r[ti].strip()
                    if not t:
                        continue
                    if key not in groups:
                        groups[key] = {"external_id": key, "customer_name": (r[ni] if ni is not None and ni < len(r) else ""), "messages": []}
                        order.append(key)
                    groups[key]["messages"].append({"role": role or "customer", "text": t, "at": (r[ai] if ai is not None and ai < len(r) else "")})
                return [groups[k] for k in order]
    # 純文字
    out, cur = [], []
    line_re = re.compile(r"^\s*(?:\[(?P<at>[^\]]+)\]\s*)?(?P<who>[^：:\[\]]{1,12})\s*[：:]\s*(?P<text>.*)$")

    def flush():
        if cur:
            out.append({"external_id": str(len(out) + 1), "customer_name": "", "messages": list(cur)})
            cur.clear()
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip() or line.strip() in ("---", "===", "——"):
            flush()
            continue
        m = line_re.match(line)
        if m and _role_of(m.group("who")):
            cur.append({"role": _role_of(m.group("who")), "text": m.group("text").strip(), "at": m.group("at") or ""})
        elif cur:
            cur[-1]["text"] += "\n" + line.strip()
    flush()
    return [c for c in out if c["messages"]]


def save_import(db: Session, account_id, name: str, convs: list, by: str) -> TranscriptImport:
    imp = TranscriptImport(account_id=account_id or None, name=name, conv_count=len(convs), created_by=by)
    db.add(imp)
    db.flush()
    for c in convs:
        db.add(TranscriptConv(import_id=imp.id, account_id=account_id or None, external_id=c.get("external_id"),
                              customer_name=c.get("customer_name") or "", messages=JSONText.dump(c["messages"]),
                              agent_count=sum(1 for m in c["messages"] if m["role"] == "agent")))
    return imp


# ---------- 取來源 ----------

def _render_conv(msgs, limit=MAX_CHARS_PER_CONV):
    lines = []
    for m in msgs:
        who = "客人" if m["role"] == "customer" else "客服"
        lines.append(f"{who}：{(m['text'] or '').strip()}")
    s = "\n".join(lines)
    return s[-limit:] if len(s) > limit else s


def pending_sources(db: Session, limit=BATCH):
    """回傳 [(kind, obj, account_id, text)]；只拿有客服回覆的"""
    out = []
    convs = (db.query(Conversation).filter(Conversation.kb_mined == False)  # noqa
             .filter(Conversation.status == "closed").order_by(Conversation.created_at.asc()).limit(limit * 3).all())
    for c in convs:
        msgs = (db.query(Message).filter(Message.conversation_id == c.id, Message.role.in_(["customer", "agent"]))
                .order_by(Message.created_at.asc()).all())
        if not any(m.role == "agent" for m in msgs):
            c.kb_mined = True   # 沒人工回覆，沒東西可學
            continue
        out.append(("conv", c, c.account_id, _render_conv([{"role": m.role, "text": m.content} for m in msgs])))
        if len(out) >= limit:
            return out
    for t in (db.query(TranscriptConv).filter(TranscriptConv.kb_mined == False).order_by(TranscriptConv.created_at.asc()).limit(limit * 3).all()):  # noqa
        if t.agent_count == 0:
            t.kb_mined = True
            continue
        out.append(("transcript", t, t.account_id, _render_conv(JSONText.load(t.messages, []))))
        if len(out) >= limit:
            break
    return out


def pending_count(db: Session):
    a = db.query(Conversation).filter(Conversation.kb_mined == False, Conversation.status == "closed").count()  # noqa
    b = db.query(TranscriptConv).filter(TranscriptConv.kb_mined == False, TranscriptConv.agent_count > 0).count()  # noqa
    return a + b


# ---------- AI ----------

def _existing_block(db: Session, account_id):
    notes = (db.query(KnowledgeNote).filter(KnowledgeNote.is_active == True)  # noqa
             .filter((KnowledgeNote.account_id == account_id) | (KnowledgeNote.account_id == None) | (KnowledgeNote.account_id == ""))  # noqa
             .order_by(KnowledgeNote.updated_at.desc()).limit(120).all())
    cands = (db.query(KnowledgeCandidate).filter(KnowledgeCandidate.status == "pending")
             .order_by(KnowledgeCandidate.created_at.desc()).limit(80).all())
    a = "\n".join(f"- id={n.id} [{n.topic}]（{n.kind}/{n.visibility}）{n.content[:160]}" for n in notes) or "（目前沒有）"
    b = "\n".join(f"- cand={c.id} [{c.topic}] {(c.answer or '')[:120]}" for c in cands) or "（目前沒有）"
    return a, b


MINE_PROMPT = """你是客服知識庫的整理員。下面是客服人員與客人的真實對話（已結束）。請從「客服實際怎麼回答」中萃取可以重複使用的知識，讓 AI 客服以後能照著回。

要萃取的：
- 事實／資訊（fact）：出貨天數、到貨時間、尺寸材質、保固、運費、付款方式、安裝方式、門市資訊、活動規則…客服說過的具體答案。
- 回覆原則（policy）：客服一貫的做法或語氣規則（例：先請客人提供訂單編號再查；破損一律請拍照；稱呼客人為您）。
- 回覆範例（example）：某類問題客服回得特別好、值得當範本的一整段回覆（原文保留）。

不要萃取的：單一客人的訂單細節、姓名電話地址、一次性的特殊處理、客人的抱怨內容本身、看不出結論的對話。

每一條要：
- topic：短標題（10 字內）
- question：客人通常怎麼問（一句）
- answer：整理成可重用的陳述（去掉個資與單次細節；example 類放客服原句）
- kind：fact / policy / example
- visibility：public（可以直接告訴客人）或 internal（只給 AI 參考，例如內部作業方式）
- confidence：0~1，客服的說法有多明確、是否多次一致
- evidence：來源（用對話編號）與原句摘錄（客服的那句），最多 3 筆
- relation：與「現有知識」或「待確認候選」的關係：new（全新）／duplicate（意思相同，給 ref）／conflict（說法矛盾，給 ref 並在 relation_note 說明哪裡不一致）
- ref：duplicate / conflict 時填現有知識的 id= 或候選的 cand=
- relation_note：衝突或重複的說明（一句）

同一批對話裡重複出現的同一件事只出一條，confidence 可以高一點。duplicate 的也要列出來（主管會看），但不用重寫得很長。

【現有知識】
{existing}

【待確認候選（還沒進知識庫）】
{cands}

【對話】
{convs}

只回傳 JSON：{{"items": [ {{...}}, ... ]}}，沒有可萃取的就回 {{"items": []}}。"""


async def mine_batch(db: Session, by: str = "系統") -> dict:
    settings = get_all_settings(db)
    client = ai_svc.get_client(settings.get("anthropic_api_key") or "")
    if not client:
        return {"ok": False, "error": "尚未設定 Anthropic API Key"}
    sources = pending_sources(db)
    if not sources:
        return {"ok": True, "mined": 0, "created": 0, "remaining": 0}
    # 同一批盡量同帳號（知識庫依帳號）；混帳號時以第一段的帳號為準
    account_id = sources[0][2]
    acc = db.get(Account, account_id) if account_id else None
    existing, cands = _existing_block(db, account_id)
    conv_text = "\n\n".join(f"【對話 {i + 1}】\n{t}" for i, (_, _, _, t) in enumerate(sources))
    prompt = MINE_PROMPT.format(existing=existing, cands=cands, convs=conv_text)
    model = settings.get("ai_model") or "claude-sonnet-4-5"
    batch_id = gen_id()
    try:
        resp = await client.messages.create(model=model, max_tokens=4000,
                                            system=f"你在整理「{acc.name if acc else '客服'}」官方帳號的客服知識。只回 JSON。",
                                            messages=[{"role": "user", "content": prompt}])
        usage = getattr(resp, "usage", None)
        db.add(AiUsage(day=datetime.utcnow().strftime("%Y-%m-%d"), account_id=account_id, model=model,
                       input_tokens=getattr(usage, "input_tokens", 0) or 0, output_tokens=getattr(usage, "output_tokens", 0) or 0))
        text = "".join(getattr(b, "text", "") for b in resp.content)
        data = ai_svc._parse_json(text) or {}
    except Exception as e:
        log.exception("知識萃取失敗")
        return {"ok": False, "error": f"{type(e).__name__}: {str(e)[:200]}"}
    items = data.get("items") if isinstance(data.get("items"), list) else []
    created = 0
    refs = {f"對話 {i + 1}": (k, o) for i, (k, o, _, _) in enumerate(sources)}
    for it in items:
        if not isinstance(it, dict) or not (it.get("answer") or "").strip():
            continue
        ev = []
        for e in (it.get("evidence") or [])[:3]:
            if isinstance(e, dict):
                src = str(e.get("source") or e.get("conversation") or "")
                m = re.search(r"對話\s*(\d+)", src)
                ref = None
                if m:
                    k = f"對話 {m.group(1)}"
                    if k in refs:
                        kind, obj = refs[k]
                        ref = {"kind": kind, "id": obj.id}
                ev.append({"source": src, "ref": ref, "excerpt": str(e.get("excerpt") or e.get("quote") or "")[:300]})
            elif isinstance(e, str):
                ev.append({"source": "", "ref": None, "excerpt": e[:300]})
        rel = it.get("relation") if it.get("relation") in ("new", "duplicate", "conflict") else "new"
        ref = str(it.get("ref") or "").strip()
        related = None
        if ref.startswith("id="):
            related = ref[3:]
        elif ref.startswith("cand="):
            related = ref[5:]
        elif ref:
            related = ref
        try:
            conf = max(0.0, min(1.0, float(it.get("confidence", 0.5))))
        except Exception:
            conf = 0.5
        db.add(KnowledgeCandidate(
            account_id=account_id, topic=str(it.get("topic") or "")[:60], question=str(it.get("question") or "")[:500],
            answer=str(it.get("answer") or "").strip()[:3000], kind=it.get("kind") if it.get("kind") in ("fact", "policy", "example") else "fact",
            visibility="internal" if it.get("visibility") == "internal" else "public", confidence=conf,
            evidence=JSONText.dump(ev), relation=rel, related_note_id=related, relation_note=str(it.get("relation_note") or "")[:500],
            batch_id=batch_id, discussion="[]"))
        created += 1
    for kind, obj, _, _ in sources:
        obj.kb_mined = True
    db.commit()
    return {"ok": True, "mined": len(sources), "created": created, "remaining": pending_count(db), "batch_id": batch_id}


DISCUSS_PROMPT = """你是客服知識庫的整理員，正在跟主管確認一條從客服對話萃取出來的知識。主管可能會：糾正內容、補充條件、問你為什麼這樣整理、指出跟別條知識矛盾。請用繁體中文、口語、簡短回答（3 句內），有需要就提出修訂版。

【這條候選】
主題：{topic}
客人問法：{question}
整理後答案：{answer}
類型：{kind}／可見性：{visibility}／信心 {confidence}
來源摘錄：
{evidence}
{related}

【相關的現有知識】
{existing}

只回傳 JSON：{{"reply": "你的回答", "proposal": null 或 {{"topic": "...", "question": "...", "answer": "...", "kind": "fact|policy|example", "visibility": "public|internal"}}}}
proposal 只在你建議修改這條候選的內容時才給（把完整修訂後的版本放進去）。"""


async def discuss(db: Session, cand: KnowledgeCandidate, user_text: str, by: str) -> dict:
    settings = get_all_settings(db)
    client = ai_svc.get_client(settings.get("anthropic_api_key") or "")
    if not client:
        return {"ok": False, "error": "尚未設定 Anthropic API Key"}
    hist = JSONText.load(cand.discussion, []) or []
    hist.append({"role": "user", "text": user_text, "at": datetime.utcnow().isoformat() + "Z", "by": by})
    related = ""
    if cand.related_note_id:
        n = db.get(KnowledgeNote, cand.related_note_id)
        if n:
            related = f"【AI 標記為{'衝突' if cand.relation == 'conflict' else '重複'}的現有知識】\n[{n.topic}] {n.content}\n說明：{cand.relation_note or ''}"
    existing, _ = _existing_block(db, cand.account_id)
    ev = "\n".join(f"- {e.get('excerpt', '')}" for e in JSONText.load(cand.evidence, []) or []) or "（無）"
    system = DISCUSS_PROMPT.format(topic=cand.topic, question=cand.question, answer=cand.answer, kind=cand.kind, visibility=cand.visibility,
                                   confidence=cand.confidence, evidence=ev, related=related, existing=existing[:6000])
    messages = [{"role": "user" if m["role"] == "user" else "assistant", "content": m["text"]} for m in hist[-12:]]
    model = settings.get("ai_model") or "claude-sonnet-4-5"
    try:
        resp = await client.messages.create(model=model, max_tokens=1200, system=system, messages=messages)
        usage = getattr(resp, "usage", None)
        db.add(AiUsage(day=datetime.utcnow().strftime("%Y-%m-%d"), account_id=cand.account_id, model=model,
                       input_tokens=getattr(usage, "input_tokens", 0) or 0, output_tokens=getattr(usage, "output_tokens", 0) or 0))
        text = "".join(getattr(b, "text", "") for b in resp.content)
        data = ai_svc._parse_json(text) or {"reply": text.strip()[:1000], "proposal": None}
    except Exception as e:
        log.exception("知識討論失敗")
        return {"ok": False, "error": f"{type(e).__name__}: {str(e)[:200]}"}
    reply = str(data.get("reply") or "").strip()
    proposal = data.get("proposal") if isinstance(data.get("proposal"), dict) else None
    hist.append({"role": "ai", "text": reply, "at": datetime.utcnow().isoformat() + "Z", "proposal": proposal})
    cand.discussion = JSONText.dump(hist)
    db.commit()
    return {"ok": True, "reply": reply, "proposal": proposal, "discussion": hist}
