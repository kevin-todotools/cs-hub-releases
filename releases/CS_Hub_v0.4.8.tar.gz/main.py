"""
CS Hub 入口（請盡量不要改這個檔：它是更新失敗時的最後防線）

- 正常：載入 app.py 裡的 FastAPI app
- 更新後第一次啟動若載入失敗：自動還原備份並重啟
- 連還原都失敗：啟動「緊急模式」，只剩更新頁，讓你還能上傳修好的版本
"""
import os
import traceback

import updater

try:
    from app import app  # noqa: F401
    updater.verify_on_boot(True)
except Exception:  # noqa: BLE001
    _err = traceback.format_exc()
    print(_err, flush=True)
    _res = updater.verify_on_boot(False, _err)
    if _res == "rolled_back":
        updater.restart_now()
    from emergency import build_app
    app = build_app(_err)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "8500")))
