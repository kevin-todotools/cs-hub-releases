#!/bin/sh
# 給 python:3.11-slim 直接 docker run 用的啟動腳本：
# docker run -d --name cs_hub --restart unless-stopped -p 8500:8500 -v /volume1/docker/cs_hub/cs_hub:/app -w /app python:3.11-slim sh /app/entrypoint.sh
cd /app
pip install -q --no-cache-dir -r requirements.txt
exec python -m uvicorn main:app --host 0.0.0.0 --port 8500
