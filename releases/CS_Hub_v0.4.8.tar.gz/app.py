import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request, Depends
from fastapi.responses import FileResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

import updater
from config import APP_DIR, read_version
from database import engine, Base, ensure_columns, SessionLocal
import models  # noqa: F401  確保所有模型註冊
from services import worker
from services.auth import ensure_default_admin, get_current_user_optional
from routers import webhook, auth as auth_router, api, admin

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("cs_hub")

STATIC = APP_DIR / "static"
RUNNING_VERSION = read_version()   # 開機時載入的版本（檔案被更新後，重啟前仍顯示舊版）


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    ensure_columns()
    with SessionLocal() as db:
        if ensure_default_admin(db):
            log.warning("已建立預設管理員 admin（密碼 admin1234，首次登入請更改）")
        # 開機時把卡在 running 的工作放回佇列
        db.query(models.Job).filter(models.Job.status == "running").update({"status": "queued"})
        db.commit()
    updater.emergency_key()
    task = asyncio.create_task(worker.run_forever())
    log.info("CS Hub %s 啟動完成", RUNNING_VERSION)
    yield
    worker.stop()
    task.cancel()


app = FastAPI(title="CS Hub", version=read_version(), lifespan=lifespan, docs_url="/api/docs", redoc_url=None)

app.include_router(webhook.router, prefix="/webhook", tags=["webhook"])
app.include_router(auth_router.router, prefix="/api/auth", tags=["auth"])
app.include_router(api.router, prefix="/api", tags=["api"])
app.include_router(admin.router, prefix="/api/admin", tags=["admin"])
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


@app.get("/health")
def health():
    return {"status": "ok", "version": RUNNING_VERSION, "started_at": updater.STARTED_AT_UTC.isoformat(timespec="seconds") + "Z",
            "started_at_local": updater.STARTED_AT.isoformat(timespec="seconds")}


@app.get("/")
def root():
    return RedirectResponse("/workbench")


NO_CACHE = {"Cache-Control": "no-cache, no-store, must-revalidate"}


@app.get("/login")
def login_page():
    return FileResponse(STATIC / "login.html", headers=NO_CACHE)


@app.get("/workbench")
@app.get("/workbench/{rest:path}")
def workbench_page(request: Request, user=Depends(get_current_user_optional)):
    if not user:
        return RedirectResponse("/login")
    return FileResponse(STATIC / "workbench.html", headers=NO_CACHE)


@app.get("/admin/update")
def update_page(user=Depends(get_current_user_optional)):
    if not user:
        return RedirectResponse("/login?next=/admin/update")
    return FileResponse(STATIC / "update.html", headers=NO_CACHE)


@app.exception_handler(StarletteHTTPException)
async def http_exc(request: Request, exc: StarletteHTTPException):
    if exc.status_code == 401 and not request.url.path.startswith("/api"):
        return RedirectResponse("/login")
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
