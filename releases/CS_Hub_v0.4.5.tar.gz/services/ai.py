"""
AI 服務：意圖判斷 + 回覆生成 + 案件欄位抽取，一次呼叫完成。
重點：
- 帶完整上下文（人設、知識庫、歷史、案件、BH 訂單、回覆範例）
- 內部備註只給 AI 參考、不可直說
- 回傳嚴格 JSON，解析失敗一律轉人工
"""
import base64
import json
import logging
import re
from datetime import datetime
from pathlib import Path
from sqlalchemy.orm import Session

from config import DEFAULT_INTENTS, CASE_INTENTS, INTENT_KEYWORDS, CASE_REQUIRED_FIELDS, CASE_FIELD_LABELS, CASE_TYPE_LABELS, APP_DIR
from models import Account, Conversation, Message, KnowledgeNote, Case, AiUsage, JSONText, Customer
from services.common import get_setting, get_all_settings, fmt_local
from services import bh

log = logging.getLogger("cs_hub.ai")

_client = None
_client_key = None


def get_client(api_key: str):
    global _client, _client_key
    if not api_key:
        return None
    if _client is None or _client_key != api_key:
        from anthropic import AsyncAnthropic
        _client = AsyncAnthropic(api_key=api_key)
        _client_key = api_key
    return _client


def intents_list(db: Session):
    raw = get_setting(db, "intents") or ""
    items = [x.strip() for x in raw.split(",") if x.strip()]
    return items or DEFAULT_INTENTS


def fallback_result(reason: str) -> dict:
    return {
        "intent": "其他", "confidence": 0.0, "risk": "medium", "need_human": True,
        "reply": "", "reason": reason, "case": None, "summary": "", "customer_sentiment": "none",
        "_fallback": True,
    }


def today_usage(db: Session) -> int:
    from sqlalchemy import func
    day = datetime.utcnow().strftime("%Y-%m-%d")
    row = db.query(func.coalesce(func.sum(AiUsage.input_tokens + AiUsage.output_tokens), 0)).filter(AiUsage.day == day).scalar()
    return int(row or 0)


def _knowledge_block(db: Session, account: Account) -> str:
    now = datetime.utcnow()
    notes = (db.query(KnowledgeNote)
             .filter(KnowledgeNote.is_active == True)  # noqa
             .filter((KnowledgeNote.account_id == account.id) | (KnowledgeNote.account_id == None) | (KnowledgeNote.account_id == ""))  # noqa
             .order_by(KnowledgeNote.updated_at.desc()).limit(80).all())
    pub, internal, policies = [], [], []
    for n in notes:
        if n.valid_until and n.valid_until < now:
            continue
        if n.kind == "example":
            continue
        line = f"- [{n.topic}] {n.content}"
        if n.kind == "policy":
            policies.append(line)
        elif n.visibility == "internal":
            internal.append(line)
        else:
            pub.append(line)
    out = []
    if policies:
        out.append("【回覆原則（必須遵守）】\n" + "\n".join(policies))
    if pub:
        out.append("【可以告訴客人的資訊】\n" + "\n".join(pub))
    if internal:
        out.append("【內部資訊：只能用來判斷怎麼回，絕對不可以把內容或日期直接告訴客人；若與公開資訊不一致，用安撫、緩衝的說法，不要承諾】\n" + "\n".join(internal))
    return "\n\n".join(out)


def _examples_block(db: Session, account: Account, intent_hint: str = None) -> str:
    q = (db.query(KnowledgeNote).filter(KnowledgeNote.is_active == True, KnowledgeNote.kind == "example")  # noqa
         .filter((KnowledgeNote.account_id == account.id) | (KnowledgeNote.account_id == None) | (KnowledgeNote.account_id == "")))  # noqa
    rows = q.order_by(KnowledgeNote.updated_at.desc()).limit(40).all()
    if intent_hint:
        pri = [r for r in rows if r.intent == intent_hint]
        rest = [r for r in rows if r.intent != intent_hint]
        rows = (pri + rest)[:12]
    else:
        rows = rows[:12]
    if not rows:
        return ""
    return "【客服回覆範例（學習人工的語氣與做法）】\n" + "\n".join(f"- ({r.intent or '通用'}) {r.content}" for r in rows)


def _history_block(db: Session, conv: Conversation, limit: int):
    msgs = (db.query(Message).filter(Message.conversation_id == conv.id, Message.role.in_(["customer", "ai", "agent"]))
            .order_by(Message.created_at.desc()).limit(limit).all())
    msgs.reverse()
    lines = []
    for m in msgs:
        who = {"customer": "客人", "ai": "AI客服", "agent": "人工客服"}[m.role]
        lines.append(f"[{fmt_local(m.created_at, '%m/%d %H:%M')}] {who}：{m.content}")
    return "\n".join(lines), msgs


def _image_blocks(msgs, max_images=3):
    """最近幾張客人傳的圖片，轉成 Claude 的 image block"""
    blocks = []
    for m in reversed(msgs):
        if m.role == "customer" and m.msg_type == "image" and m.media_path:
            p = APP_DIR / m.media_path if not Path(m.media_path).is_absolute() else Path(m.media_path)
            if p.exists() and p.stat().st_size < 4_500_000:
                ext = p.suffix.lower().lstrip(".")
                media_type = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "gif": "image/gif", "webp": "image/webp"}.get(ext)
                if media_type:
                    blocks.append({"type": "image", "source": {"type": "base64", "media_type": media_type,
                                                               "data": base64.b64encode(p.read_bytes()).decode()}})
        if len(blocks) >= max_images:
            break
    return blocks


def _case_block(case: Case) -> str:
    if not case:
        return ""
    fields = JSONText.load(case.fields, {})
    req = CASE_REQUIRED_FIELDS.get(case.case_type, CASE_REQUIRED_FIELDS["other"])
    have = "\n".join(f"- {CASE_FIELD_LABELS.get(k, k)}：{v}" for k, v in fields.items() if v not in (None, ""))
    missing = [CASE_FIELD_LABELS.get(k, k) for k in req if fields.get(k) in (None, "")]
    return (f"【進行中的案件：{CASE_TYPE_LABELS.get(case.case_type, case.case_type)}（狀態 {case.status}）】\n"
            f"已收集：\n{have or '（尚無）'}\n尚缺：{'、'.join(missing) or '無，資料已齊全'}")


SYSTEM_PROMPT = """你是「{account_name}」官方 LINE 的客服 AI，代表這家台灣的電商賣家回覆客人。
{persona}

工作方式：
1. 先判斷客人這次訊息的意圖（從清單選一個）、你的信心（0~1）、風險（low/medium/high）。
2. 用繁體中文（台灣用語）寫一則適合直接傳給客人的回覆，口氣親切、簡短、一次只問一件事，不要用 markdown、不要條列符號。
3. 只能依據「可以告訴客人的資訊」與對話內容回答；沒有把握的事（到貨日、庫存、價格、能不能退）不要編造、不要承諾，改說「我幫您確認後回覆」並把 need_human 設為 true。
4. 內部資訊只能用來決定怎麼安撫、怎麼措辭，絕對不能直接透露內容。
5. 遇到抱怨、生氣、威脅、要求賠償、法律、媒體、評價威脅、或你無法處理的事：risk 設 high、need_human 設 true，回覆先安撫並說明會請專人處理。
6. 補寄缺件／商品損壞／未收到貨／退換貨：這是「案件」。請從對話中抽取已知欄位，判斷還缺什麼，然後只問下一個最重要的缺項（一次一個）。若客人傳了照片，請把 photo 設為「已提供」並簡述照片內容。欄位齊全時 complete 設 true，並告訴客人已記錄、會請專人審核處理。
7. 若客人只是閒聊、貼圖、說謝謝，可給簡短回應，need_human 設 false。

意圖清單：{intents}
意圖常見說法（客人常這樣講）：{intent_hints}
案件類型對應：{case_map}
案件欄位代碼：{case_fields}
目前時間：{now}（台灣）。{hours_note}

只回傳一個 JSON 物件，不要任何其他文字，格式：
{{
  "intent": "意圖",
  "confidence": 0.0,
  "risk": "low|medium|high",
  "need_human": false,
  "reply": "給客人的回覆文字",
  "reason": "一句話說明你的判斷（給客服看）",
  "summary": "這段對話到目前為止的一句話摘要",
  "customer_sentiment": "positive|neutral|negative",
  "case": null 或 {{"type": "reship|damage|not_received|return|other", "fields": {{"欄位代碼": "值"}}, "complete": false}}
}}"""


async def analyze(db: Session, account: Account, conv: Conversation, trigger_msg: Message) -> dict:
    settings = get_all_settings(db)
    api_key = settings.get("anthropic_api_key") or ""
    client = get_client(api_key)
    if not client:
        return fallback_result("未設定 Anthropic API Key，全部轉人工")

    cap = int(settings.get("ai_daily_token_cap") or 0)
    if cap and today_usage(db) >= cap:
        return fallback_result("今日 AI 用量已達上限，轉人工")

    limit = int(settings.get("ai_history_messages") or 20)
    history, msgs = _history_block(db, conv, limit)
    case = (db.query(Case).filter(Case.conversation_id == conv.id, Case.status.in_(["clarifying", "review"]))
            .order_by(Case.created_at.desc()).first())

    # BH 訂單查詢（有設定才查）
    bh_text = ""
    if settings.get("bh_base_url"):
        keys = []
        for m in msgs[-6:]:
            if m.role == "customer":
                keys += bh.extract_order_keys(m.content)
        if case:
            on = JSONText.load(case.fields, {}).get("order_number")
            if on:
                keys.append(str(on))
        # 客人資料裡存的手機 / 識別鍵（之前客服填的）也拿來查
        cust = db.get(Customer, conv.customer_id) if conv.customer_id else None
        for extra in ((cust.phone if cust else ""), (cust.person_key if cust else "")):
            if extra and len(extra) >= 6:
                keys.append(extra.strip())
        seen = []
        for k in keys:
            if k not in seen:
                seen.append(k)
        for k in seen[:3]:
            data = await bh.lookup_orders(settings["bh_base_url"], settings.get("bh_api_token", ""), k)
            s = bh.summarize_orders(data)
            if s:
                bh_text += f"查詢「{k}」：\n{s}\n"

    from services.common import in_business_hours
    hours_note = "現在是上班時間。" if in_business_hours(db) else "現在是非上班時間，若需要人工，請告知客人上班時間會儘速處理。"

    system = SYSTEM_PROMPT.format(
        account_name=account.name,
        persona=(account.ai_persona or "").strip(),
        intents="、".join(intents_list(db)),
        intent_hints="；".join(f"{k}：{'、'.join(v)}" for k, v in INTENT_KEYWORDS.items() if k in intents_list(db)),
        case_map="、".join(f"{k}→{v}" for k, v in CASE_INTENTS.items()),
        case_fields="、".join(f"{k}={v}" for k, v in CASE_FIELD_LABELS.items()),
        now=fmt_local(datetime.utcnow(), "%Y-%m-%d %H:%M"),
        hours_note=hours_note,
    )

    parts = []
    menu = JSONText.load(account.faq_menu, [])
    if menu:
        parts.append("【主選單固定答案（客人問到相關問題可直接引用）】\n" + "\n".join(f"- [{it.get('label')}] {it.get('reply')}" for it in menu))
    kb = _knowledge_block(db, account)
    if kb:
        parts.append(kb)
    ex = _examples_block(db, account, conv.intent)
    if ex:
        parts.append(ex)
    if bh_text:
        parts.append("【BH 訂單系統查詢結果——這是真實訂單狀態，回答出貨 / 到貨 / 付款問題一律以此為準，不要憑空猜】\n"
                     "規則：「可告知客人」那一行與付款 / 出貨狀態、託運單號、品項可以直接說；標 [內部註記]、[店家備註]、[聯繫紀錄]、[時間軸] 的只能參考，不可逐字說出；"
                     "廠商名稱、成本、黑名單不可提。查無訂單或多張訂單時，請客人提供訂單編號或下單手機確認。\n" + bh_text)
    cb = _case_block(case)
    if cb:
        parts.append(cb)
    parts.append("【對話紀錄（最後一則是客人剛傳來的）】\n" + (history or "（無）"))
    parts.append("請針對客人最後的訊息做判斷並回傳 JSON。")

    content = [{"type": "text", "text": "\n\n".join(parts)}]
    content += _image_blocks(msgs)

    model = settings.get("ai_model") or "claude-sonnet-4-5"
    try:
        resp = await client.messages.create(
            model=model, max_tokens=900, system=system,
            messages=[{"role": "user", "content": content}],
        )
        usage = getattr(resp, "usage", None)
        db.add(AiUsage(day=datetime.utcnow().strftime("%Y-%m-%d"), account_id=account.id, model=model,
                       input_tokens=getattr(usage, "input_tokens", 0) or 0,
                       output_tokens=getattr(usage, "output_tokens", 0) or 0))
        text = "".join(getattr(b, "text", "") for b in resp.content)
        result = _parse_json(text)
        if not result:
            return fallback_result("AI 回傳格式無法解析，轉人工")
        return _normalize(result, db)
    except Exception as e:
        log.exception("AI 呼叫失敗")
        return fallback_result(f"AI 呼叫失敗：{type(e).__name__}: {str(e)[:200]}")


def _parse_json(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    s, e = text.find("{"), text.rfind("}")
    if s < 0 or e <= s:
        return None
    try:
        return json.loads(text[s:e + 1])
    except Exception:
        return None


def _normalize(r: dict, db: Session) -> dict:
    valid = intents_list(db)
    intent = r.get("intent") or "其他"
    if intent not in valid:
        intent = "其他"
    try:
        conf = float(r.get("confidence", 0))
    except Exception:
        conf = 0.0
    risk = r.get("risk") if r.get("risk") in ("low", "medium", "high") else "medium"
    case = r.get("case")
    if isinstance(case, dict):
        ctype = case.get("type") if case.get("type") in CASE_REQUIRED_FIELDS else "other"
        fields = case.get("fields") if isinstance(case.get("fields"), dict) else {}
        case = {"type": ctype, "fields": {k: str(v) for k, v in fields.items() if v not in (None, "")},
                "complete": bool(case.get("complete"))}
    else:
        case = None
    return {
        "intent": intent, "confidence": max(0.0, min(1.0, conf)), "risk": risk,
        "need_human": bool(r.get("need_human")), "reply": (r.get("reply") or "").strip(),
        "reason": (r.get("reason") or "").strip(), "summary": (r.get("summary") or "").strip(),
        "customer_sentiment": r.get("customer_sentiment") if r.get("customer_sentiment") in ("positive", "neutral", "negative") else "neutral",
        "case": case,
    }
