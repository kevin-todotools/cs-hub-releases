from sqlalchemy import Column, String, Text, Boolean, DateTime, Integer, Float, ForeignKey, Index
from sqlalchemy.sql import func
from database import Base
import uuid
import json
from datetime import datetime


def gen_id():
    return uuid.uuid4().hex


class JSONText:
    """小工具：把 Text 欄位當 JSON 用"""
    @staticmethod
    def load(s, default=None):
        if not s:
            return default if default is not None else {}
        try:
            return json.loads(s)
        except Exception:
            return default if default is not None else {}

    @staticmethod
    def dump(obj):
        return json.dumps(obj, ensure_ascii=False)


# ---------- 帳號與使用者 ----------

class Account(Base):
    """一個 LINE 官方帳號 = 一筆"""
    __tablename__ = "accounts"
    id = Column(String, primary_key=True, default=gen_id)
    code = Column(String, unique=True, nullable=False)     # 短代碼，用在 webhook 網址，如 furniture
    name = Column(String, nullable=False)                  # 顯示名稱，如 家具收納
    channel_secret = Column(String, default="")
    channel_access_token = Column(Text, default="")
    ai_persona = Column(Text, default="")                  # 這個帳號的 AI 人設／商品背景
    greeting = Column(Text, default="")                    # 非上班時間自動回覆
    enabled = Column(Boolean, default=True)
    forward_url = Column(Text, default="")                 # 影子模式：把 LINE webhook 原封不動轉給另一個系統（如 Omnichat）
    shadow_mode = Column(Boolean, default=False)           # 影子模式：AI 只旁聽寫草稿、不自動回、不轉人工佇列
    faq_menu = Column(Text, default="[]")                  # 進線主選單（quick reply）：[{"label":..,"reply":..}]
    color = Column(String, default="#2563eb")
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, server_default=func.now())


class User(Base):
    """工作台使用者（客服／主管／管理員）"""
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=gen_id)
    username = Column(String, unique=True, nullable=False)
    display_name = Column(String, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, default="agent")                 # agent / manager / admin
    is_active = Column(Boolean, default=True)
    online = Column(Boolean, default=False)                # 是否在線（接受指派）
    account_ids = Column(Text, default="[]")               # 可處理哪些帳號（空 = 全部）
    must_change_password = Column(Boolean, default=False)
    last_seen_at = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())


class Session(Base):
    __tablename__ = "sessions"
    id = Column(String, primary_key=True, default=gen_id)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    expires_at = Column(DateTime)
    user_agent = Column(String)


# ---------- 客人與對話 ----------

class Customer(Base):
    """同一個人在不同官方帳號裡 line_user_id 不同，用 person_key（手機／訂單）串起來"""
    __tablename__ = "customers"
    id = Column(String, primary_key=True, default=gen_id)
    account_id = Column(String, ForeignKey("accounts.id"), nullable=False)
    line_user_id = Column(String, nullable=False)
    display_name = Column(String)
    picture_url = Column(String)
    phone = Column(String)
    person_key = Column(String)                            # 跨帳號識別鍵
    tags = Column(Text, default="[]")
    notes = Column(Text, default="")                       # 客服對這個客人的備註
    blocked = Column(Boolean, default=False)
    created_at = Column(DateTime, server_default=func.now())
    __table_args__ = (Index("ix_customer_acc_line", "account_id", "line_user_id", unique=True),)


class Conversation(Base):
    """一段對話（會結案；結案後再來訊息會開新對話）"""
    __tablename__ = "conversations"
    id = Column(String, primary_key=True, default=gen_id)
    account_id = Column(String, ForeignKey("accounts.id"), nullable=False)
    customer_id = Column(String, ForeignKey("customers.id"), nullable=False)
    status = Column(String, default="ai")                  # ai / pending / human / closed
    intent = Column(String)
    risk = Column(String)                                  # low / medium / high
    priority = Column(Integer, default=0)                  # 越大越前面
    assignee_id = Column(String, ForeignKey("users.id"))
    ai_paused = Column(Boolean, default=False)             # 人工介入後 AI 停手
    unread_count = Column(Integer, default=0)              # 客人新訊息尚未被人工看過
    last_message_at = Column(DateTime)
    last_customer_message_at = Column(DateTime)
    last_agent_message_at = Column(DateTime)
    waiting_since = Column(DateTime)                       # 客人等候起點（有新訊息且尚未回）
    first_response_seconds = Column(Integer)
    needs_review = Column(Boolean, default=False)          # AI 自動送出待抽查
    human_touched = Column(Boolean, default=False)         # 曾經需要人工（轉人工／指派／人工回覆）
    summary = Column(Text)                                 # AI 摘要
    closed_at = Column(DateTime)
    closed_by = Column(String)
    close_reason = Column(String)
    reopened_from = Column(String)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    __table_args__ = (
        Index("ix_conv_status", "account_id", "status"),
        Index("ix_conv_customer", "customer_id", "status"),
    )


class Message(Base):
    __tablename__ = "messages"
    id = Column(String, primary_key=True, default=gen_id)
    conversation_id = Column(String, ForeignKey("conversations.id"), nullable=False, index=True)
    role = Column(String, nullable=False)                  # customer / ai / agent / system / ai_draft
    content = Column(Text, default="")
    msg_type = Column(String, default="text")              # text / image / sticker / video / audio / file / location
    media_path = Column(String)                            # data/media/...
    line_message_id = Column(String)
    reply_token = Column(String)
    reply_token_at = Column(DateTime)
    sender_user_id = Column(String)                        # agent 的 user id
    ai_meta = Column(Text)                                 # AI 判斷的完整 JSON
    delivery = Column(String)                              # pending / sent / failed / draft
    delivery_error = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)   # Python 端產生，有微秒，排序才穩


# ---------- 案件 ----------

class Case(Base):
    __tablename__ = "cases"
    id = Column(String, primary_key=True, default=gen_id)
    account_id = Column(String, ForeignKey("accounts.id"))
    conversation_id = Column(String, ForeignKey("conversations.id"), index=True)
    customer_id = Column(String, ForeignKey("customers.id"))
    case_type = Column(String, default="other")            # reship / damage / not_received / return / other
    status = Column(String, default="clarifying")          # clarifying / review / processing / done / cancelled
    fields = Column(Text, default="{}")                    # 收集到的欄位 JSON
    missing_fields = Column(Text, default="[]")
    form_text = Column(Text)                               # 產生的可複製表單
    decision = Column(Text)                                # 人工決定（免費補寄／收費／退回壞件…）
    handler_id = Column(String, ForeignKey("users.id"))
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    closed_at = Column(DateTime)


# ---------- 知識、學習、範本 ----------

class KnowledgeNote(Base):
    __tablename__ = "knowledge_notes"
    id = Column(String, primary_key=True, default=gen_id)
    account_id = Column(String)                            # 空 = 所有帳號共用
    topic = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    visibility = Column(String, default="public")          # public: 可以告訴客人 / internal: 只給 AI 參考不可直說
    kind = Column(String, default="fact")                  # fact / example（回覆範例） / policy
    intent = Column(String)                                # 關聯意圖（example 類用）
    source = Column(String, default="manual")              # manual / learning
    valid_until = Column(DateTime)                         # 有時效的資訊（如到貨日）
    is_active = Column(Boolean, default=True)
    created_by = Column(String)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class LearningRecord(Base):
    """每一次 AI 被人工修正／評價都留一筆"""
    __tablename__ = "learning_records"
    id = Column(String, primary_key=True, default=gen_id)
    account_id = Column(String)
    conversation_id = Column(String)
    message_id = Column(String)
    intent = Column(String)
    customer_text = Column(Text)                           # 客人原話
    ai_draft = Column(Text)                                # AI 原本的回覆
    human_final = Column(Text)                             # 人工最後送出的
    kind = Column(String)                                  # accepted / edited / rejected / rated_good / rated_bad
    customer_signal = Column(String)                       # 客人之後反應：positive / negative / none
    reviewed = Column(Boolean, default=False)              # 主管是否已審閱
    promoted_note_id = Column(String)                      # 若已轉成知識條目
    agent_id = Column(String)
    created_at = Column(DateTime, server_default=func.now())


class AutonomyRule(Base):
    """每個帳號 × 意圖的自主權等級"""
    __tablename__ = "autonomy_rules"
    id = Column(String, primary_key=True, default=gen_id)
    account_id = Column(String, nullable=False)
    intent = Column(String, nullable=False)
    level = Column(Integer, default=1)
    min_confidence = Column(Float, default=0.8)            # 低於此信心一律降為草稿
    __table_args__ = (Index("ix_autonomy_acc_intent", "account_id", "intent", unique=True),)


class ReplyTemplate(Base):
    __tablename__ = "reply_templates"
    id = Column(String, primary_key=True, default=gen_id)
    account_id = Column(String)                            # 空 = 共用
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    shortcut = Column(String)                              # 快捷鍵字，如 /到貨
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, server_default=func.now())


# ---------- 系統 ----------

class Setting(Base):
    __tablename__ = "settings"
    key = Column(String, primary_key=True)
    value = Column(Text)


class Job(Base):
    """背景工作佇列（持久化，重啟不丟）"""
    __tablename__ = "jobs"
    id = Column(String, primary_key=True, default=gen_id)
    kind = Column(String, nullable=False)                  # ai_process / line_send / media_fetch / profile_fetch
    payload = Column(Text, default="{}")
    status = Column(String, default="queued")              # queued / running / done / failed
    attempts = Column(Integer, default=0)
    last_error = Column(Text)
    run_after = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())
    finished_at = Column(DateTime)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(String, primary_key=True, default=gen_id)
    user_id = Column(String)
    user_name = Column(String)
    action = Column(String, nullable=False)
    target_type = Column(String)
    target_id = Column(String)
    detail = Column(Text)
    created_at = Column(DateTime, server_default=func.now())


class AiUsage(Base):
    """AI 用量（每日成本上限用）"""
    __tablename__ = "ai_usage"
    id = Column(String, primary_key=True, default=gen_id)
    day = Column(String, index=True)                       # YYYY-MM-DD
    account_id = Column(String)
    model = Column(String)
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    calls = Column(Integer, default=1)
    created_at = Column(DateTime, server_default=func.now())


class UpdateHistory(Base):
    __tablename__ = "update_history"
    id = Column(String, primary_key=True, default=gen_id)
    from_version = Column(String)
    to_version = Column(String)
    filename = Column(String)
    backup_path = Column(String)
    result = Column(String)                                # success / rolled_back / failed
    detail = Column(Text)
    user_name = Column(String)
    created_at = Column(DateTime, server_default=func.now())
