"""共用小工具：設定讀寫、稽核紀錄、時間"""
from datetime import datetime, timedelta, timezone
from sqlalchemy.orm import Session
from models import Setting, AuditLog, JSONText

TZ = timezone(timedelta(hours=8))

DEFAULT_SETTINGS = {
    "anthropic_api_key": "",
    "ai_model": "claude-sonnet-4-5",
    "ai_daily_token_cap": "3000000",       # 每日 token 上限（輸入+輸出），0 = 不限
    "emergency_draft_mode": "0",           # 1 = 所有帳號強制降為草稿模式
    "business_hours": "09:00-18:00",       # 上班時間（台灣）
    "business_days": "1,2,3,4,5",          # 週一=1
    "off_hours_reply": "您好，已收到您的訊息，目前為非上班時間，客服將於上班時間儘速回覆您。",
    "sla_warning_minutes": "10",           # 等候超過幾分鐘標紅
    "poll_interval_seconds": "5",
    "bh_base_url": "",
    "bh_api_token": "",
    "intents": "",                         # 逗號分隔，空 = 用預設
    "auto_close_hours": "72",              # 客人多久沒回自動結案（0 = 不自動）
    "ai_history_messages": "20",           # 給 AI 的歷史訊息數
    "notify_line_group_webhook": "",       # 逾時提醒推到 TODO Bot 的網址（選用）
    "update_source_url": "",               # latest.json 網址（遠端自動更新）
    "auto_update_mode": "notify",          # off / notify（只提醒）/ auto（自動安裝）
    "auto_update_hour": "4",               # auto 模式幾點安裝（台灣時間，0–23）
}


def now_utc():
    return datetime.utcnow()


def to_local(dt):
    if not dt:
        return None
    return dt.replace(tzinfo=timezone.utc).astimezone(TZ)


def fmt_local(dt, fmt="%m-%d %H:%M"):
    l = to_local(dt)
    return l.strftime(fmt) if l else ""


def get_setting(db: Session, key: str, default=None):
    row = db.get(Setting, key)
    if row is None or row.value is None:
        return DEFAULT_SETTINGS.get(key, default) if default is None else default
    return row.value


def get_all_settings(db: Session) -> dict:
    out = dict(DEFAULT_SETTINGS)
    for row in db.query(Setting).all():
        out[row.key] = row.value
    return out


def set_setting(db: Session, key: str, value):
    row = db.get(Setting, key)
    if row is None:
        row = Setting(key=key, value=str(value))
        db.add(row)
    else:
        row.value = str(value)


def audit(db: Session, user, action: str, target_type=None, target_id=None, detail=None):
    db.add(AuditLog(
        user_id=getattr(user, "id", None),
        user_name=getattr(user, "display_name", None) or (user if isinstance(user, str) else "system"),
        action=action, target_type=target_type, target_id=target_id,
        detail=JSONText.dump(detail) if isinstance(detail, (dict, list)) else detail,
    ))


def in_business_hours(db: Session, at: datetime = None) -> bool:
    at = to_local(at or now_utc())
    days = {int(x) for x in get_setting(db, "business_days").split(",") if x.strip().isdigit()}
    if at.isoweekday() not in days:
        return False
    try:
        start, end = get_setting(db, "business_hours").split("-")
        sh, sm = map(int, start.split(":"))
        eh, em = map(int, end.split(":"))
    except Exception:
        return True
    minutes = at.hour * 60 + at.minute
    return sh * 60 + sm <= minutes < eh * 60 + em
