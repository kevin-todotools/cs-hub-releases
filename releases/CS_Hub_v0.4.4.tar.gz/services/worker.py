"""
背景 worker：從 jobs 表取工作執行。單一 asyncio 迴圈，依序處理（每日數百則綽綽有餘）。
工作種類：
- ai_process：AI 判斷 + 依自主權等級決定草稿／自動送出／轉人工 + 案件更新
- line_send：把一則訊息送到 LINE（reply token 新鮮就 reply，否則 push）
- media_fetch：下載客人傳的圖片等
- profile_fetch：抓客人的顯示名稱
- housekeeping：逾時提醒、自動結案
"""
import asyncio
import json
import logging
import mimetypes
from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy.orm import Session

from config import (MEDIA_DIR, APP_DIR, CASE_INTENTS, CASE_REQUIRED_FIELDS, CASE_FIELD_LABELS, CASE_TYPE_LABELS,
                    AUTONOMY_OBSERVE, AUTONOMY_DRAFT, AUTONOMY_AUTO_REVIEW, AUTONOMY_AUTO)
from database import session_scope, SessionLocal
from models import Job, Message, Conversation, Account, Customer, Case, AutonomyRule, LearningRecord, JSONText
from services import line as line_api
from services import convo
from services import ai as ai_svc
from services.common import get_setting, in_business_hours, now_utc

log = logging.getLogger("cs_hub.worker")
_wake = asyncio.Event()
_running = False


def wake():
    try:
        _wake.set()
    except Exception:
        pass


async def run_forever():
    global _running
    _running = True
    log.info("worker 啟動")
    last_housekeeping = datetime.min
    while _running:
        try:
            did = await process_one()
            if (datetime.utcnow() - last_housekeeping).total_seconds() > 60:
                await housekeeping()
                last_housekeeping = datetime.utcnow()
            if not did:
                _wake.clear()
                try:
                    await asyncio.wait_for(_wake.wait(), timeout=3)
                except asyncio.TimeoutError:
                    pass
        except Exception:
            log.exception("worker 迴圈錯誤")
            await asyncio.sleep(2)


def stop():
    global _running
    _running = False
    wake()


async def process_one() -> bool:
    db = SessionLocal()
    try:
        now = datetime.utcnow()
        job = (db.query(Job).filter(Job.status == "queued")
               .filter((Job.run_after == None) | (Job.run_after <= now))  # noqa
               .order_by(Job.created_at).first())
        if not job:
            return False
        job.status = "running"
        job.attempts = (job.attempts or 0) + 1
        db.commit()
        payload = JSONText.load(job.payload, {})
        try:
            handler = HANDLERS.get(job.kind)
            if not handler:
                raise RuntimeError(f"未知工作類型 {job.kind}")
            await handler(db, payload)
            db.commit()
            job.status = "done"
            job.finished_at = datetime.utcnow()
            db.commit()
        except Exception as e:
            db.rollback()
            log.exception("工作 %s 失敗", job.kind)
            job = db.get(Job, job.id)
            job.last_error = f"{type(e).__name__}: {str(e)[:500]}"
            if job.attempts < 3 and job.kind in ("line_send", "media_fetch", "profile_fetch"):
                job.status = "queued"
                job.run_after = datetime.utcnow() + timedelta(seconds=15 * job.attempts)
            else:
                job.status = "failed"
                job.finished_at = datetime.utcnow()
                if job.kind == "ai_process":
                    _ai_failed_to_human(db, payload, job.last_error)
            db.commit()
        return True
    finally:
        db.close()


def _ai_failed_to_human(db: Session, payload: dict, err: str):
    conv = db.get(Conversation, payload.get("conversation_id"))
    if conv and conv.status == "ai":
        convo.set_status(db, conv, "pending", "系統", f"AI 處理失敗，轉人工：{err[:120]}")


# ---------- handlers ----------

async def handle_profile_fetch(db: Session, p: dict):
    cust = db.get(Customer, p["customer_id"])
    if not cust:
        return
    acc = db.get(Account, cust.account_id)
    if not acc or not acc.channel_access_token:
        return
    prof = await line_api.get_profile(acc.channel_access_token, cust.line_user_id)
    if prof:
        cust.display_name = prof.get("displayName")
        cust.picture_url = prof.get("pictureUrl")


async def handle_media_fetch(db: Session, p: dict):
    msg = db.get(Message, p["message_id"])
    acc = db.get(Account, p["account_id"])
    if not msg or not acc or not acc.channel_access_token or not msg.line_message_id:
        return
    data, ctype = await line_api.get_content(acc.channel_access_token, msg.line_message_id)
    if not data:
        raise RuntimeError("下載媒體失敗")
    ext = mimetypes.guess_extension(ctype.split(";")[0].strip()) or ".bin"
    if ext == ".jpe":
        ext = ".jpg"
    folder = MEDIA_DIR / acc.code
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{msg.id}{ext}"
    path.write_bytes(data)
    msg.media_path = str(path.relative_to(APP_DIR))


async def handle_line_send(db: Session, p: dict):
    msg = db.get(Message, p["message_id"])
    if not msg or msg.delivery == "sent":
        return
    conv = db.get(Conversation, msg.conversation_id)
    acc = db.get(Account, conv.account_id)
    cust = db.get(Customer, conv.customer_id)
    if not acc.channel_access_token:
        msg.delivery = "failed"
        msg.delivery_error = "此帳號尚未設定 Channel Access Token"
        return
    status, text = None, None
    reply_token = p.get("reply_token")
    token_at = p.get("reply_token_at")
    quick = None
    if p.get("with_menu"):
        quick = [it["label"] for it in JSONText.load(acc.faq_menu, []) if it.get("label")] or None
    if reply_token and token_at:
        age = (datetime.utcnow() - datetime.fromisoformat(token_at)).total_seconds()
        if age < line_api.REPLY_TOKEN_SAFE_SECONDS:
            status, text = await line_api.reply_message(acc.channel_access_token, reply_token, msg.content, quick)
    if status != 200:
        status, text = await line_api.push_message(acc.channel_access_token, cust.line_user_id, msg.content, quick)
    if status == 200:
        msg.delivery = "sent"
        msg.delivery_error = None
    else:
        msg.delivery = "failed"
        msg.delivery_error = f"LINE {status}: {text[:300] if text else ''}"
        raise RuntimeError(msg.delivery_error)


def _autonomy(db: Session, account_id: str, intent: str):
    rule = db.query(AutonomyRule).filter_by(account_id=account_id, intent=intent).first()
    if rule:
        return rule.level, rule.min_confidence
    return AUTONOMY_DRAFT, 0.8


def _fresh_token(msg: Message):
    if msg.reply_token and msg.reply_token_at:
        return {"reply_token": msg.reply_token, "reply_token_at": msg.reply_token_at.isoformat()}
    return {}


async def handle_ai_process(db: Session, p: dict):
    msg = db.get(Message, p["message_id"])
    conv = db.get(Conversation, p["conversation_id"])
    acc = db.get(Account, p["account_id"])
    if not msg or not conv or not acc:
        return
    if conv.status in ("human", "closed") or conv.ai_paused:
        return
    # 合併處理：若客人之後又傳了訊息，這則先略過，由最後一則一起處理
    newer = (db.query(Message).filter(Message.conversation_id == conv.id, Message.role == "customer",
                                      Message.created_at > msg.created_at).count())
    if newer:
        return
    # 圖片還沒下載完就等一下再處理（最多等兩次）
    pending_media = db.query(Job).filter(Job.kind == "media_fetch", Job.status.in_(["queued", "running"])).count()
    if pending_media and msg.msg_type != "text" and p.get("_media_wait", 0) < 2:
        p["_media_wait"] = p.get("_media_wait", 0) + 1
        convo.enqueue(db, "ai_process", p, run_after=datetime.utcnow() + timedelta(seconds=4))
        return

    # 主選單：客人點了快速回覆按鈕（文字完全等於某個選項）→ 固定答案，不用 AI
    faq = {it["label"]: it["reply"] for it in JSONText.load(acc.faq_menu, []) if it.get("label")}
    if msg.msg_type == "text" and msg.content.strip() in faq and not acc.shadow_mode:
        out = convo.add_outbound_message(db, conv, "ai", faq[msg.content.strip()], ai_meta={"faq": msg.content.strip()}, delivery="pending")
        convo.enqueue(db, "line_send", {"message_id": out.id, **_fresh_token(msg), "with_menu": True})
        conv.intent = conv.intent or "主選單"
        return
    first_contact = db.query(Message).filter(Message.conversation_id == conv.id, Message.role == "customer").count() == 1

    result = await ai_svc.analyze(db, acc, conv, msg)
    msg.ai_meta = JSONText.dump(result)
    conv.intent = result["intent"]
    conv.risk = result["risk"]
    if result.get("summary"):
        conv.summary = result["summary"]

    # 把客人的反應回寫到上一筆學習紀錄
    last_lr = (db.query(LearningRecord).filter(LearningRecord.conversation_id == conv.id, LearningRecord.customer_signal == None)  # noqa
               .order_by(LearningRecord.created_at.desc()).first())
    if last_lr:
        last_lr.customer_signal = result.get("customer_sentiment", "neutral")

    # 案件更新
    case_complete = _update_case(db, conv, acc, result)

    # 影子模式：只寫草稿、標記抽查，不送、不轉人工、不佔佇列
    if acc.shadow_mode:
        result["_effective_level"] = AUTONOMY_DRAFT
        result["_level_reasons"] = ["影子模式（旁聽）"]
        msg.ai_meta = JSONText.dump(result)
        if result.get("reply"):
            convo.add_outbound_message(db, conv, "ai_draft", result["reply"], ai_meta=result, delivery="draft")
        conv.status = "ai"
        conv.needs_review = True
        conv.waiting_since = None
        return

    # 自主權判定
    level, min_conf = _autonomy(db, acc.id, result["intent"])
    emergency = get_setting(db, "emergency_draft_mode") == "1"
    reasons = []
    if emergency and level > AUTONOMY_DRAFT:
        level = AUTONOMY_DRAFT
        reasons.append("緊急草稿模式")
    if result.get("_fallback"):
        level = AUTONOMY_OBSERVE
    if result["need_human"] and level > AUTONOMY_DRAFT:
        level = AUTONOMY_DRAFT
        reasons.append("AI 要求人工")
    if result["risk"] == "high" and level > AUTONOMY_DRAFT:
        level = AUTONOMY_DRAFT
        reasons.append("高風險")
    if result["confidence"] < min_conf and level > AUTONOMY_DRAFT:
        level = AUTONOMY_DRAFT
        reasons.append(f"信心 {result['confidence']:.2f} 低於門檻 {min_conf}")
    if case_complete and level > AUTONOMY_DRAFT:
        # 案件資料齊全：讓 AI 自動告知「已記錄」，但同時轉人工審核
        pass
    result["_effective_level"] = level
    result["_level_reasons"] = reasons
    msg.ai_meta = JSONText.dump(result)

    reply = result.get("reply") or ""
    if level >= AUTONOMY_AUTO_REVIEW and reply:
        out = convo.add_outbound_message(db, conv, "ai", reply, ai_meta=result, delivery="pending")
        convo.enqueue(db, "line_send", {"message_id": out.id, **_fresh_token(msg), "with_menu": first_contact and bool(faq)})
        if level == AUTONOMY_AUTO_REVIEW:
            conv.needs_review = True
        if result["need_human"] or case_complete:
            convo.set_status(db, conv, "pending", "AI", "AI 已回覆並轉人工" + ("（案件資料齊全待審核）" if case_complete else ""))
            _auto_assign(db, conv)
        else:
            conv.status = "ai"
    else:
        if reply and level >= AUTONOMY_DRAFT:
            convo.add_outbound_message(db, conv, "ai_draft", reply, ai_meta=result, delivery="draft")
        note = "AI 轉人工：" + (result.get("reason") or "") + (("（" + "、".join(reasons) + "）") if reasons else "")
        convo.set_status(db, conv, "pending", "AI", note)
        # 非上班時間先給客人一個交代（每段對話只送一次）
        if not in_business_hours(db):
            already = db.query(Message).filter(Message.conversation_id == conv.id, Message.role == "ai",
                                               Message.ai_meta == '{"off_hours": true}').count()
            off_text = get_setting(db, "off_hours_reply")
            if not already and off_text:
                out = convo.add_outbound_message(db, conv, "ai", off_text, ai_meta={"off_hours": True}, delivery="pending")
                convo.enqueue(db, "line_send", {"message_id": out.id, **_fresh_token(msg)})
                conv.waiting_since = msg.created_at  # 仍視為等候中
                conv.unread_count = 1
        _auto_assign(db, conv)


def _auto_assign(db: Session, conv: Conversation):
    if get_setting(db, "auto_assign", "1") != "1":
        return
    if conv.assignee_id:
        return
    u = convo.pick_auto_assignee(db, conv.account_id)
    if u:
        convo.assign(db, conv, u.id, "系統", f"系統自動指派給 {u.display_name}")


def _update_case(db: Session, conv: Conversation, acc: Account, result: dict) -> bool:
    """依 AI 回傳更新／建立案件；回傳是否剛達成資料齊全"""
    c = result.get("case")
    intent = result.get("intent")
    case = (db.query(Case).filter(Case.conversation_id == conv.id, Case.status.in_(["clarifying", "review"]))
            .order_by(Case.created_at.desc()).first())
    if not c and intent not in CASE_INTENTS:
        return False
    ctype = (c or {}).get("type") or CASE_INTENTS.get(intent, "other")
    if not case:
        case = Case(account_id=acc.id, conversation_id=conv.id, customer_id=conv.customer_id, case_type=ctype,
                    status="clarifying", fields="{}")
        db.add(case)
        db.flush()
        convo.add_system_message(db, conv, f"建立案件：{CASE_TYPE_LABELS.get(ctype, ctype)}")
    fields = JSONText.load(case.fields, {})
    if c:
        for k, v in (c.get("fields") or {}).items():
            if v:
                fields[k] = v
    # 客人傳過圖片就算有照片
    if db.query(Message).filter(Message.conversation_id == conv.id, Message.msg_type == "image").count():
        fields.setdefault("photo", "已提供")
    case.fields = JSONText.dump(fields)
    req = CASE_REQUIRED_FIELDS.get(case.case_type, CASE_REQUIRED_FIELDS["other"])
    missing = [k for k in req if fields.get(k) in (None, "")]
    case.missing_fields = JSONText.dump(missing)
    newly_complete = False
    if (not missing or (c and c.get("complete"))) and case.status == "clarifying":
        case.status = "review"
        case.form_text = build_form_text(db, case, conv)
        newly_complete = True
        convo.add_system_message(db, conv, "案件資料已齊全，待人工審核")
    return newly_complete


def build_form_text(db: Session, case: Case, conv: Conversation = None) -> str:
    conv = conv or db.get(Conversation, case.conversation_id)
    acc = db.get(Account, case.account_id)
    cust = db.get(Customer, case.customer_id)
    fields = JSONText.load(case.fields, {})
    lines = [f"【{CASE_TYPE_LABELS.get(case.case_type, case.case_type)}表單】",
             f"帳號：{acc.name if acc else '-'}",
             f"客人：{(cust.display_name if cust else None) or '-'}（LINE {cust.line_user_id[:8] if cust else ''}…）"]
    for k in CASE_REQUIRED_FIELDS.get(case.case_type, CASE_REQUIRED_FIELDS["other"]) + ["new_address"]:
        if k in fields or k != "new_address":
            lines.append(f"{CASE_FIELD_LABELS.get(k, k)}：{fields.get(k) or '-'}")
    lines.append(f"處理決定：{case.decision or '待確認'}")
    lines.append(f"建立時間：{case.created_at.strftime('%Y-%m-%d %H:%M') if case.created_at else '-'}")
    return "\n".join(lines)


_last_remote_check = datetime.min


async def remote_update_tick():
    """每小時檢查一次更新來源；auto 模式在指定時段自動安裝"""
    global _last_remote_check
    if (datetime.utcnow() - _last_remote_check).total_seconds() < 3600:
        return
    _last_remote_check = datetime.utcnow()
    import updater
    from services.common import to_local
    with session_scope() as db:
        url = get_setting(db, "update_source_url")
        mode = get_setting(db, "auto_update_mode")
        hour = int(get_setting(db, "auto_update_hour") or 4)
    if not url or mode == "off":
        return
    try:
        st = await asyncio.get_event_loop().run_in_executor(None, updater.check_remote, url)
    except Exception as e:
        log.warning("檢查更新失敗：%s", e)
        return
    if st.get("available") and mode == "auto" and to_local(datetime.utcnow()).hour == hour:
        try:
            r = await asyncio.get_event_loop().run_in_executor(None, updater.apply_remote, url, "auto")
            if r.get("applied"):
                with session_scope() as db:
                    from services.common import audit
                    audit(db, "system", "system.update_remote", detail=r)
                updater.schedule_restart(1.5)
        except Exception as e:
            log.exception("自動更新失敗：%s", e)


async def housekeeping():
    await remote_update_tick()
    with session_scope() as db:
        hours = int(get_setting(db, "auto_close_hours") or 0)
        if hours > 0:
            cutoff = datetime.utcnow() - timedelta(hours=hours)
            stale = (db.query(Conversation).filter(Conversation.status.in_(["ai", "human", "pending"]))
                     .filter(Conversation.last_message_at != None, Conversation.last_message_at < cutoff)  # noqa
                     .filter(Conversation.waiting_since == None).all())  # noqa 只結案「客人沒再回」的
            for c in stale:
                convo.set_status(db, c, "closed", "系統", f"客人超過 {hours} 小時未回覆，系統自動結案")
                for case in db.query(Case).filter(Case.conversation_id == c.id, Case.status == "clarifying").all():
                    case.status = "cancelled"
        # 清掉舊的 done job
        db.query(Job).filter(Job.status == "done", Job.finished_at < datetime.utcnow() - timedelta(days=3)).delete()


async def handle_forward_retry(db: Session, p: dict):
    import base64
    from routers.webhook import forward_webhook
    ok = await forward_webhook(p["url"], base64.b64decode(p["body_b64"]), p.get("signature", ""), p.get("account_id"), attempt=p.get("attempt", 2))
    if not ok and p.get("attempt", 2) >= 3:
        from services.common import audit
        audit(db, "system", "webhook.forward_failed", "account", p.get("account_id"), {"url": p["url"]})


async def handle_ai_draft(db: Session, p: dict):
    """人工要求 AI 重新產生草稿：不改狀態、不自動送出"""
    msg = db.get(Message, p["message_id"])
    conv = db.get(Conversation, p["conversation_id"])
    acc = db.get(Account, p["account_id"])
    if not msg or not conv or not acc:
        return
    result = await ai_svc.analyze(db, acc, conv, msg)
    if result.get("reply"):
        result["_effective_level"] = AUTONOMY_DRAFT
        result["_level_reasons"] = ["人工要求草稿"]
        convo.add_outbound_message(db, conv, "ai_draft", result["reply"], ai_meta=result, delivery="draft")
    else:
        convo.add_system_message(db, conv, "AI 無法產生草稿：" + (result.get("reason") or ""))


HANDLERS = {
    "ai_process": handle_ai_process,
    "ai_draft": handle_ai_draft,
    "forward_retry": handle_forward_retry,
    "line_send": handle_line_send,
    "media_fetch": handle_media_fetch,
    "profile_fetch": handle_profile_fetch,
}
