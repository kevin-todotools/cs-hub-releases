"""
BH 訂單系統連接器（之後確認 BH 實際 API 後只需要改這個檔）
目前假設：GET {bh_base_url}/api/orders?q=<訂單編號或手機>  Header: Authorization: Bearer <token>
回傳 list 或 {"orders": [...]}
"""
import logging
import re
import httpx

log = logging.getLogger("cs_hub.bh")
ORDER_NO_RE = re.compile(r"\b[A-Za-z]{0,4}\d{6,}\b")
PHONE_RE = re.compile(r"\b09\d{8}\b")


def extract_order_keys(text: str):
    keys = []
    if not text:
        return keys
    keys += PHONE_RE.findall(text)
    keys += [k for k in ORDER_NO_RE.findall(text) if k not in keys]
    return keys[:3]


async def lookup_orders(base_url: str, token: str, query: str):
    if not base_url or not query:
        return None
    try:
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(f"{base_url.rstrip('/')}/api/orders", params={"q": query}, headers=headers)
        if r.status_code != 200:
            return {"error": f"BH 回應 {r.status_code}"}
        data = r.json()
        if isinstance(data, dict) and "orders" in data:
            data = data["orders"]
        return data
    except Exception as e:
        log.warning("BH 查詢失敗: %s", e)
        return {"error": str(e)}


def summarize_orders(data) -> str:
    """把 BH 回傳變成給 AI 看的精簡文字；欄位名稱盡量容錯"""
    if not data:
        return ""
    if isinstance(data, dict) and "error" in data:
        return f"（BH 查詢失敗：{data['error']}）"
    lines = []
    for o in (data if isinstance(data, list) else [data])[:5]:
        if not isinstance(o, dict):
            continue
        parts = []
        for k in ("order_number", "order_no", "id", "status", "shipping_status", "vendor", "eta", "arrival_date",
                  "tracking_no", "items", "internal_note", "note", "created_at"):
            if k in o and o[k] not in (None, ""):
                parts.append(f"{k}={o[k]}")
        if parts:
            lines.append("；".join(str(p) for p in parts))
    return "\n".join(lines)
