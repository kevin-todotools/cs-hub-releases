"""管理 API：帳號、使用者、自主權、設定、更新"""
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel
from sqlalchemy.orm import Session

import updater
from config import AUTONOMY_LABELS, DEFAULT_INTENTS, ROLES


def read_version():
    import app
    return app.RUNNING_VERSION
from database import get_db
from models import Account, User, AutonomyRule, AuditLog, Job, UpdateHistory, JSONText
from services.auth import require_admin, require_manager, require_user, hash_password, public_user
from services.common import get_all_settings, set_setting, audit, DEFAULT_SETTINGS
from services.ai import intents_list
from services import line as line_api

router = APIRouter()


# ---------- 帳號（官方 LINE） ----------

class AccountIn(BaseModel):
    code: str
    name: str
    channel_secret: Optional[str] = None
    channel_access_token: Optional[str] = None
    ai_persona: Optional[str] = ""
    greeting: Optional[str] = ""
    enabled: bool = True
    color: Optional[str] = "#2563eb"
    sort_order: int = 0
    forward_url: Optional[str] = ""
    shadow_mode: bool = False
    faq_menu: Optional[str] = "[]"


def _valid_menu(raw):
    """faq_menu：JSON 陣列 [{"label": "訂單進度查詢", "reply": "..."}]，最多 13 個（LINE quick reply 上限）"""
    import json as _json
    try:
        items = _json.loads(raw or "[]")
    except Exception:
        raise HTTPException(400, "主選單格式錯誤（需為 JSON 陣列）")
    out = []
    for it in items if isinstance(items, list) else []:
        if isinstance(it, dict) and it.get("label") and it.get("reply"):
            out.append({"label": str(it["label"])[:20], "reply": str(it["reply"])[:4000]})
    return _json.dumps(out[:13], ensure_ascii=False)


def _acc_row(a: Account, full=False):
    r = {"id": a.id, "code": a.code, "name": a.name, "enabled": a.enabled, "color": a.color, "sort_order": a.sort_order,
         "ai_persona": a.ai_persona, "greeting": a.greeting,
         "forward_url": a.forward_url or "", "shadow_mode": bool(a.shadow_mode), "faq_menu": a.faq_menu or "[]",
         "has_secret": bool(a.channel_secret), "has_token": bool(a.channel_access_token),
         "webhook_path": f"/webhook/line/{a.code}"}
    if full:
        r["channel_secret_masked"] = "已設定" if a.channel_secret else ""
        r["channel_access_token_masked"] = "已設定" if a.channel_access_token else ""
    return r


@router.get("/accounts")
def list_accounts(db: Session = Depends(get_db), user=Depends(require_manager)):
    return {"items": [_acc_row(a, True) for a in db.query(Account).order_by(Account.sort_order, Account.name).all()]}


@router.post("/accounts")
def create_account(data: AccountIn, db: Session = Depends(get_db), user=Depends(require_admin)):
    code = data.code.strip().lower()
    if not code.replace("_", "").replace("-", "").isalnum():
        raise HTTPException(400, "代碼只能用英文、數字、底線")
    if db.query(Account).filter_by(code=code).first():
        raise HTTPException(400, "代碼已存在")
    a = Account(code=code, name=data.name.strip(), channel_secret=(data.channel_secret or "").strip(),
                channel_access_token=(data.channel_access_token or "").strip(), ai_persona=data.ai_persona or "",
                greeting=data.greeting or "", enabled=data.enabled, color=data.color or "#2563eb", sort_order=data.sort_order,
                forward_url=(data.forward_url or "").strip(), shadow_mode=data.shadow_mode, faq_menu=_valid_menu(data.faq_menu))
    db.add(a)
    db.flush()
    # 預設自主權：全部草稿
    for it in intents_list(db):
        db.add(AutonomyRule(account_id=a.id, intent=it, level=1, min_confidence=0.8))
    audit(db, user, "account.create", "account", a.id, {"code": code})
    db.commit()
    return {"ok": True, "item": _acc_row(a, True)}


@router.put("/accounts/{acc_id}")
def update_account(acc_id: str, data: AccountIn, db: Session = Depends(get_db), user=Depends(require_admin)):
    a = db.get(Account, acc_id)
    if not a:
        raise HTTPException(404)
    a.name, a.ai_persona, a.greeting, a.enabled, a.color, a.sort_order = data.name.strip(), data.ai_persona or "", data.greeting or "", data.enabled, data.color or a.color, data.sort_order
    a.forward_url = (data.forward_url or "").strip()
    a.shadow_mode = data.shadow_mode
    a.faq_menu = _valid_menu(data.faq_menu)
    if data.channel_secret:        # 空白 = 不改
        a.channel_secret = data.channel_secret.strip()
    if data.channel_access_token:
        a.channel_access_token = data.channel_access_token.strip()
    audit(db, user, "account.update", "account", a.id)
    db.commit()
    return {"ok": True, "item": _acc_row(a, True)}


@router.get("/accounts/{acc_id}/quota")
async def account_quota(acc_id: str, db: Session = Depends(get_db), user=Depends(require_manager)):
    a = db.get(Account, acc_id)
    if not a or not a.channel_access_token:
        raise HTTPException(400, "尚未設定 Access Token")
    return await line_api.get_quota(a.channel_access_token)


# ---------- 自主權 ----------

@router.get("/autonomy")
def get_autonomy(db: Session = Depends(get_db), user=Depends(require_manager)):
    intents = intents_list(db)
    accs = db.query(Account).order_by(Account.sort_order, Account.name).all()
    rules = {(r.account_id, r.intent): r for r in db.query(AutonomyRule).all()}
    matrix = []
    for a in accs:
        row = {"account_id": a.id, "account_name": a.name, "rules": {}}
        for it in intents:
            r = rules.get((a.id, it))
            row["rules"][it] = {"level": r.level if r else 1, "min_confidence": r.min_confidence if r else 0.8}
        matrix.append(row)
    return {"intents": intents, "levels": AUTONOMY_LABELS, "matrix": matrix}


class AutonomyIn(BaseModel):
    account_id: str
    intent: str
    level: int
    min_confidence: Optional[float] = None


@router.post("/autonomy")
def set_autonomy(data: AutonomyIn, db: Session = Depends(get_db), user=Depends(require_manager)):
    if data.level not in AUTONOMY_LABELS:
        raise HTTPException(400, "等級錯誤")
    r = db.query(AutonomyRule).filter_by(account_id=data.account_id, intent=data.intent).first()
    if not r:
        r = AutonomyRule(account_id=data.account_id, intent=data.intent)
        db.add(r)
    r.level = data.level
    if data.min_confidence is not None:
        r.min_confidence = max(0.0, min(1.0, data.min_confidence))
    audit(db, user, "autonomy.set", "account", data.account_id, {"intent": data.intent, "level": data.level})
    db.commit()
    return {"ok": True}


@router.post("/autonomy/bulk")
def set_autonomy_bulk(account_id: str, level: int, db: Session = Depends(get_db), user=Depends(require_manager)):
    for it in intents_list(db):
        r = db.query(AutonomyRule).filter_by(account_id=account_id, intent=it).first()
        if not r:
            r = AutonomyRule(account_id=account_id, intent=it)
            db.add(r)
        r.level = level
    audit(db, user, "autonomy.bulk", "account", account_id, {"level": level})
    db.commit()
    return {"ok": True}


# ---------- 使用者 ----------

class UserIn(BaseModel):
    username: Optional[str] = None
    display_name: str
    password: Optional[str] = None
    role: str = "agent"
    is_active: bool = True
    account_ids: list = []


@router.get("/users")
def admin_list_users(db: Session = Depends(get_db), user=Depends(require_manager)):
    return {"items": [public_user(u) for u in db.query(User).order_by(User.created_at).all()]}


@router.post("/users")
def create_user(data: UserIn, db: Session = Depends(get_db), user=Depends(require_admin)):
    if not data.username or not data.password:
        raise HTTPException(400, "需要帳號與密碼")
    if data.role not in ROLES:
        raise HTTPException(400, "角色錯誤")
    if db.query(User).filter_by(username=data.username.strip()).first():
        raise HTTPException(400, "帳號已存在")
    u = User(username=data.username.strip(), display_name=data.display_name.strip(), password_hash=hash_password(data.password),
             role=data.role, is_active=data.is_active, account_ids=JSONText.dump(data.account_ids or []), must_change_password=True)
    db.add(u)
    audit(db, user, "user.create", "user", None, {"username": u.username, "role": u.role})
    db.commit()
    return {"ok": True, "item": public_user(u)}


@router.put("/users/{uid}")
def update_user(uid: str, data: UserIn, db: Session = Depends(get_db), user=Depends(require_admin)):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(404)
    if data.role not in ROLES:
        raise HTTPException(400, "角色錯誤")
    if u.id == user.id and data.role != "admin":
        raise HTTPException(400, "不能把自己降級")
    u.display_name, u.role, u.is_active = data.display_name.strip(), data.role, data.is_active
    u.account_ids = JSONText.dump(data.account_ids or [])
    if data.password:
        u.password_hash = hash_password(data.password)
        u.must_change_password = True
    audit(db, user, "user.update", "user", u.id, {"role": u.role, "active": u.is_active})
    db.commit()
    return {"ok": True, "item": public_user(u)}


# ---------- 設定 ----------

SECRET_KEYS = {"anthropic_api_key", "bh_api_token"}


@router.get("/settings")
def get_settings(db: Session = Depends(get_db), user=Depends(require_manager)):
    s = get_all_settings(db)
    out = {}
    for k, v in s.items():
        if k in SECRET_KEYS:
            out[k] = "已設定" if v else ""
        else:
            out[k] = v
    out["_defaults"] = DEFAULT_SETTINGS
    out["_default_intents"] = DEFAULT_INTENTS
    return out


@router.put("/settings")
def put_settings(data: dict, db: Session = Depends(get_db), user=Depends(require_admin)):
    changed = []
    for k, v in data.items():
        if k.startswith("_") or k not in DEFAULT_SETTINGS and k != "auto_assign":
            continue
        if k in SECRET_KEYS and (not v or str(v).startswith("已設定")):
            continue
        set_setting(db, k, "1" if v is True else "0" if v is False else str(v))
        changed.append(k)
    audit(db, user, "settings.update", detail={"keys": changed})
    db.commit()
    return {"ok": True, "changed": changed}


@router.post("/settings/emergency")
def toggle_emergency(on: bool, db: Session = Depends(get_db), user=Depends(require_manager)):
    set_setting(db, "emergency_draft_mode", "1" if on else "0")
    audit(db, user, "settings.emergency", detail={"on": on})
    db.commit()
    return {"ok": True, "on": on}


@router.post("/settings/test-ai")
async def test_ai(db: Session = Depends(get_db), user=Depends(require_admin)):
    s = get_all_settings(db)
    if not s.get("anthropic_api_key"):
        raise HTTPException(400, "尚未設定 API Key")
    try:
        from anthropic import AsyncAnthropic
        c = AsyncAnthropic(api_key=s["anthropic_api_key"])
        r = await c.messages.create(model=s.get("ai_model") or "claude-sonnet-4-5", max_tokens=20,
                                    messages=[{"role": "user", "content": "回覆「連線成功」四個字"}])
        return {"ok": True, "reply": "".join(getattr(b, "text", "") for b in r.content), "model": s.get("ai_model")}
    except Exception as e:
        raise HTTPException(400, f"測試失敗：{type(e).__name__}: {str(e)[:300]}")


# ---------- 稽核／系統狀態 ----------

@router.get("/audit")
def audit_logs(limit: int = 200, db: Session = Depends(get_db), user=Depends(require_manager)):
    rows = db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
    return {"items": [{"id": r.id, "user": r.user_name, "action": r.action, "target_type": r.target_type,
                       "target_id": r.target_id, "detail": r.detail, "created_at": r.created_at.isoformat() + "Z" if r.created_at else None} for r in rows]}


@router.get("/system")
def system_status(db: Session = Depends(get_db), user=Depends(require_manager)):
    from sqlalchemy import func
    jobs = dict(db.query(Job.status, func.count(Job.id)).group_by(Job.status).all())
    failed = db.query(Job).filter(Job.status == "failed").order_by(Job.created_at.desc()).limit(10).all()
    return {"version": read_version(), "started_at": updater.STARTED_AT.isoformat(timespec="seconds"),
            "jobs": jobs, "failed_jobs": [{"kind": j.kind, "error": j.last_error, "at": j.created_at.isoformat() if j.created_at else None} for j in failed],
            "update_state": updater.read_state()}


@router.post("/jobs/retry-failed")
def retry_failed(db: Session = Depends(get_db), user=Depends(require_manager)):
    n = db.query(Job).filter(Job.status == "failed").update({"status": "queued", "attempts": 0})
    db.commit()
    from services.worker import wake
    wake()
    return {"ok": True, "requeued": n}


# ---------- 更新 ----------

@router.get("/update/status")
def update_status(db: Session = Depends(get_db), user=Depends(require_admin)):
    hist = db.query(UpdateHistory).order_by(UpdateHistory.created_at.desc()).limit(30).all()
    st = updater.read_state()
    # 把上次重啟後的驗證結果補寫進歷史
    if st.get("result") and not st.get("_recorded"):
        db.add(UpdateHistory(from_version=st.get("from_version"), to_version=st.get("to_version"), filename=st.get("filename"),
                             backup_path=st.get("backup"), result=st.get("result"), detail=st.get("error") or st.get("pip"),
                             user_name=st.get("user")))
        st["_recorded"] = True
        updater.write_state(st)
        db.commit()
        hist = db.query(UpdateHistory).order_by(UpdateHistory.created_at.desc()).limit(30).all()
    return {
        "version": read_version(), "started_at": updater.STARTED_AT.isoformat(timespec="seconds"),
        "state": st, "backups": updater.list_backups(), "log": updater.read_log(60),
        "emergency_key": updater.emergency_key(),
        "remote": updater.read_remote_state(),
        "remote_settings": {k: get_all_settings(db).get(k) for k in ("update_source_url", "auto_update_mode", "auto_update_hour")},
        "history": [{"from": h.from_version, "to": h.to_version, "filename": h.filename, "result": h.result,
                     "detail": h.detail, "user": h.user_name, "at": h.created_at.isoformat() + "Z" if h.created_at else None} for h in hist],
        "entry": " ".join(getattr(os.sys, "orig_argv", None) or os.sys.argv),
    }


@router.post("/update/check")
def update_check(db: Session = Depends(get_db), user=Depends(require_admin)):
    url = get_all_settings(db).get("update_source_url", "")
    try:
        return updater.check_remote(url)
    except updater.UpdateError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa
        raise HTTPException(400, f"檢查失敗：{type(e).__name__}: {str(e)[:200]}")


@router.post("/update/apply-remote")
def update_apply_remote(db: Session = Depends(get_db), user=Depends(require_admin)):
    url = get_all_settings(db).get("update_source_url", "")
    try:
        r = updater.apply_remote(url, user.display_name)
    except updater.UpdateError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa
        raise HTTPException(500, f"更新失敗：{type(e).__name__}: {str(e)[:300]}")
    if r.get("applied"):
        audit(db, user, "system.update_remote", detail=r)
        db.commit()
        updater.schedule_restart(1.5)
    return r


@router.post("/update/upload")
async def update_upload(file: UploadFile = File(...), db: Session = Depends(get_db), user=Depends(require_admin)):
    name = Path(file.filename or "update.tar.gz").name
    if not name.endswith((".tar.gz", ".tgz", ".zip", ".tar")):
        raise HTTPException(400, "只接受 .tar.gz / .tgz / .zip")
    tmp = updater.TMP_DIR / f"upload_{int(datetime.now().timestamp())}_{name}"
    content = await file.read()
    tmp.write_bytes(content)
    try:
        info = updater.apply_update(tmp, user.display_name)
    except updater.UpdateError as e:
        tmp.unlink(missing_ok=True)
        updater.log(f"更新被拒絕：{e}")
        raise HTTPException(400, f"更新被拒絕（系統未變動）：{e}")
    except Exception as e:  # noqa
        tmp.unlink(missing_ok=True)
        updater.log(f"更新失敗：{e}")
        raise HTTPException(500, f"更新失敗：{e}")
    tmp.unlink(missing_ok=True)
    audit(db, user, "system.update", detail=info)
    db.commit()
    updater.schedule_restart(1.5)
    return {"ok": True, **info, "message": f"已套用 {info['to_version']}，正在重新啟動（約 5–15 秒）"}


@router.post("/update/restore")
def update_restore(name: str, db: Session = Depends(get_db), user=Depends(require_admin)):
    try:
        v = updater.restore_backup(name)
    except updater.UpdateError as e:
        raise HTTPException(400, str(e))
    updater.write_state({"pending_verify": True, "from_version": read_version(), "to_version": v, "backup": name,
                         "filename": f"(還原) {name}", "user": user.display_name, "applied_at": datetime.now().isoformat(timespec="seconds")})
    audit(db, user, "system.restore", detail={"backup": name})
    db.commit()
    updater.schedule_restart(1.5)
    return {"ok": True, "message": f"已還原到 {v}，正在重新啟動"}


@router.post("/update/restart")
def update_restart(db: Session = Depends(get_db), user=Depends(require_admin)):
    audit(db, user, "system.restart")
    db.commit()
    updater.schedule_restart(1.0)
    return {"ok": True, "message": "正在重新啟動"}


@router.post("/update/backup")
def update_backup(db: Session = Depends(get_db), user=Depends(require_admin)):
    p = updater.make_backup("manual")
    audit(db, user, "system.backup", detail={"backup": p.name})
    db.commit()
    return {"ok": True, "backup": p.name}
