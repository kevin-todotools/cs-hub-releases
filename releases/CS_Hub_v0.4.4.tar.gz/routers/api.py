"""工作台 API"""
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from config import (APP_DIR, CASE_TYPE_LABELS, CASE_REQUIRED_FIELDS, CASE_FIELD_LABELS, CONV_STATUS_LABELS,
                    DEFAULT_INTENTS)
from database import get_db
from models import (Conversation, Customer, Message, Account, User, Case, KnowledgeNote, LearningRecord,
                    ReplyTemplate, JSONText, AiUsage)
from services.auth import require_user, require_manager, user_account_ids, public_user
from services import convo
from services.common import audit, get_setting
from services.worker import wake, build_form_text
from services.ai import intents_list

router = APIRouter()


# ---------- 共用序列化 ----------

def _iso(dt):
    return dt.isoformat() + "Z" if dt else None


def _conv_row(c: Conversation, cust: Customer, acc: Account, last: Message, assignee: User, case_status=None):
    now = datetime.utcnow()
    return {
        "id": c.id, "status": c.status, "status_label": CONV_STATUS_LABELS.get(c.status, c.status),
        "intent": c.intent, "risk": c.risk, "priority": c.priority, "needs_review": c.needs_review,
        "unread_count": c.unread_count or 0, "ai_paused": c.ai_paused, "summary": c.summary,
        "waiting_seconds": int((now - c.waiting_since).total_seconds()) if c.waiting_since else None,
        "last_message_at": _iso(c.last_message_at), "created_at": _iso(c.created_at),
        "closed_at": _iso(c.closed_at),
        "customer": {"id": cust.id, "name": cust.display_name or f"客人 {cust.line_user_id[-6:]}", "picture_url": cust.picture_url,
                     "phone": cust.phone, "blocked": cust.blocked},
        "account": {"id": acc.id, "code": acc.code, "name": acc.name, "color": acc.color},
        "assignee": {"id": assignee.id, "name": assignee.display_name} if assignee else None,
        "last_message": {"role": last.role, "content": (last.content or "")[:80], "msg_type": last.msg_type} if last else None,
        "case_status": case_status,
    }


def _msg_row(m: Message):
    return {
        "id": m.id, "role": m.role, "content": m.content, "msg_type": m.msg_type,
        "media_url": f"/api/messages/{m.id}/media" if m.media_path else None,
        "sender_user_id": m.sender_user_id, "delivery": m.delivery, "delivery_error": m.delivery_error,
        "ai_meta": JSONText.load(m.ai_meta, None) if m.ai_meta else None,
        "created_at": _iso(m.created_at),
    }


def _case_row(c: Case, db: Session):
    handler = db.get(User, c.handler_id) if c.handler_id else None
    fields = JSONText.load(c.fields, {})
    req = CASE_REQUIRED_FIELDS.get(c.case_type, CASE_REQUIRED_FIELDS["other"])
    return {
        "id": c.id, "conversation_id": c.conversation_id, "customer_id": c.customer_id, "account_id": c.account_id,
        "case_type": c.case_type, "case_type_label": CASE_TYPE_LABELS.get(c.case_type, c.case_type),
        "status": c.status, "fields": fields, "required_fields": req, "field_labels": CASE_FIELD_LABELS,
        "missing_fields": [k for k in req if fields.get(k) in (None, "")],
        "form_text": c.form_text, "decision": c.decision,
        "handler": {"id": handler.id, "name": handler.display_name} if handler else None,
        "created_at": _iso(c.created_at), "updated_at": _iso(c.updated_at),
    }


def _accessible_account_ids(db: Session, user: User):
    ids = user_account_ids(user)
    if ids:
        return ids
    return [a.id for a in db.query(Account.id).all()]


def _get_conv(db: Session, conv_id: str, user: User) -> Conversation:
    conv = db.get(Conversation, conv_id)
    if not conv:
        raise HTTPException(404, "找不到對話")
    if conv.account_id not in _accessible_account_ids(db, user):
        raise HTTPException(403, "你沒有這個帳號的權限")
    return conv


# ---------- 佇列 ----------

@router.get("/queue")
def queue(view: str = "mine", account_id: Optional[str] = None, q: Optional[str] = None,
          limit: int = 200, db: Session = Depends(get_db), user=Depends(require_user)):
    acc_ids = _accessible_account_ids(db, user)
    base = db.query(Conversation).filter(Conversation.account_id.in_(acc_ids))
    if account_id:
        base = base.filter(Conversation.account_id == account_id)

    def apply_view(qry, v):
        if v == "mine":
            return qry.filter(Conversation.assignee_id == user.id, Conversation.status != "closed")
        if v == "pending":
            return qry.filter(Conversation.status == "pending")
        if v == "human":
            return qry.filter(Conversation.status == "human")
        if v == "ai":
            return qry.filter(Conversation.status == "ai")
        if v == "review":
            return qry.filter(Conversation.needs_review == True, Conversation.status != "closed")  # noqa
        if v == "closed":
            return qry.filter(Conversation.status == "closed")
        if v == "all":
            return qry.filter(Conversation.status != "closed")
        return qry

    counts = {v: apply_view(base, v).count() for v in ("mine", "pending", "human", "ai", "review", "all")}
    qry = apply_view(base, view)
    if q:
        like = f"%{q}%"
        cust_ids = [c.id for c in db.query(Customer.id).filter(
            Customer.account_id.in_(acc_ids),
            or_(Customer.display_name.like(like), Customer.phone.like(like), Customer.line_user_id.like(like))).all()]
        msg_conv_ids = [m.conversation_id for m in db.query(Message.conversation_id).filter(Message.content.like(like))
                        .order_by(Message.created_at.desc()).limit(300).all()]
        qry = qry.filter(or_(Conversation.customer_id.in_(cust_ids), Conversation.id.in_(msg_conv_ids)))
    if view == "closed":
        qry = qry.order_by(Conversation.closed_at.desc())
    else:
        # 等候中的優先，等最久的在前；再看 priority；再看最後訊息時間
        qry = qry.order_by(Conversation.priority.desc(), Conversation.waiting_since.asc().nullslast(),
                           Conversation.last_message_at.desc())
    convs = qry.limit(limit).all()

    cust_map = {c.id: c for c in db.query(Customer).filter(Customer.id.in_([x.customer_id for x in convs])).all()} if convs else {}
    acc_map = {a.id: a for a in db.query(Account).all()}
    user_map = {u.id: u for u in db.query(User).all()}
    conv_ids = [c.id for c in convs]
    last_msgs = {}
    if conv_ids:
        sub = (db.query(Message.conversation_id, func.max(Message.created_at).label("mx"))
               .filter(Message.conversation_id.in_(conv_ids), Message.role.in_(["customer", "ai", "agent", "ai_draft"]))
               .group_by(Message.conversation_id).subquery())
        for m in (db.query(Message).join(sub, (Message.conversation_id == sub.c.conversation_id) & (Message.created_at == sub.c.mx))
                  .filter(Message.role.in_(["customer", "ai", "agent", "ai_draft"])).all()):
            last_msgs[m.conversation_id] = m
    case_status = {}
    if conv_ids:
        for c in db.query(Case).filter(Case.conversation_id.in_(conv_ids), Case.status.in_(["clarifying", "review", "processing"])).all():
            case_status[c.conversation_id] = c.status
    rows = [_conv_row(c, cust_map.get(c.customer_id), acc_map.get(c.account_id), last_msgs.get(c.id),
                      user_map.get(c.assignee_id), case_status.get(c.id)) for c in convs if c.customer_id in cust_map]
    return {"items": rows, "counts": counts, "server_time": _iso(datetime.utcnow())}


# ---------- 對話 ----------

@router.get("/conversations/{conv_id}")
def conversation_detail(conv_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    cust = db.get(Customer, conv.customer_id)
    acc = db.get(Account, conv.account_id)
    assignee = db.get(User, conv.assignee_id) if conv.assignee_id else None
    msgs = db.query(Message).filter(Message.conversation_id == conv.id).order_by(Message.created_at).all()
    cases = db.query(Case).filter(Case.conversation_id == conv.id).order_by(Case.created_at.desc()).all()
    history = (db.query(Conversation).filter(Conversation.customer_id == cust.id, Conversation.id != conv.id)
               .order_by(Conversation.created_at.desc()).limit(10).all())
    other_cases = (db.query(Case).filter(Case.customer_id == cust.id, Case.conversation_id != conv.id)
                   .order_by(Case.created_at.desc()).limit(10).all())
    users = {u.id: u.display_name for u in db.query(User).all()}
    return {
        "conversation": _conv_row(conv, cust, acc, None, assignee),
        "customer": {"id": cust.id, "name": cust.display_name, "picture_url": cust.picture_url, "phone": cust.phone,
                     "person_key": cust.person_key, "tags": JSONText.load(cust.tags, []), "notes": cust.notes,
                     "line_user_id": cust.line_user_id, "blocked": cust.blocked, "created_at": _iso(cust.created_at)},
        "messages": [dict(_msg_row(m), sender_name=users.get(m.sender_user_id)) for m in msgs],
        "cases": [_case_row(c, db) for c in cases],
        "history": [{"id": h.id, "status": h.status, "intent": h.intent, "summary": h.summary,
                     "created_at": _iso(h.created_at), "closed_at": _iso(h.closed_at)} for h in history],
        "other_cases": [_case_row(c, db) for c in other_cases],
    }


@router.get("/messages/{msg_id}/media")
def message_media(msg_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    m = db.get(Message, msg_id)
    if not m or not m.media_path:
        raise HTTPException(404)
    p = Path(m.media_path)
    if not p.is_absolute():
        p = APP_DIR / p
    if not p.exists():
        raise HTTPException(404)
    return FileResponse(p)


class SendIn(BaseModel):
    content: str
    draft_message_id: Optional[str] = None
    close_after: bool = False


@router.post("/conversations/{conv_id}/send")
def send_message(conv_id: str, data: SendIn, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    content = data.content.strip()
    if not content:
        raise HTTPException(400, "內容不可空白")
    # 學習紀錄：有草稿就比對
    draft = None
    if data.draft_message_id:
        draft = db.get(Message, data.draft_message_id)
    if not draft:
        draft = (db.query(Message).filter(Message.conversation_id == conv.id, Message.role == "ai_draft", Message.delivery == "draft")
                 .order_by(Message.created_at.desc()).first())
    last_cust = (db.query(Message).filter(Message.conversation_id == conv.id, Message.role == "customer")
                 .order_by(Message.created_at.desc()).first())
    if draft:
        kind = "accepted" if draft.content.strip() == content else "edited"
        draft.delivery = "used"
        db.add(LearningRecord(account_id=conv.account_id, conversation_id=conv.id, message_id=draft.id, intent=conv.intent,
                              customer_text=last_cust.content if last_cust else None, ai_draft=draft.content,
                              human_final=content, kind=kind, agent_id=user.id))
    else:
        db.add(LearningRecord(account_id=conv.account_id, conversation_id=conv.id, intent=conv.intent,
                              customer_text=last_cust.content if last_cust else None, ai_draft=None,
                              human_final=content, kind="human_only", agent_id=user.id))
    msg = convo.add_outbound_message(db, conv, "agent", content, sender_user_id=user.id, delivery="pending")
    if conv.status != "human":
        conv.status = "human"
    conv.ai_paused = True
    conv.human_touched = True
    if not conv.assignee_id:
        conv.assignee_id = user.id
    # 若客人最後一則的 reply token 還新鮮就用（省 push 配額）
    token = {}
    if last_cust and last_cust.reply_token and last_cust.reply_token_at and \
            (datetime.utcnow() - last_cust.reply_token_at).total_seconds() < 40:
        token = {"reply_token": last_cust.reply_token, "reply_token_at": last_cust.reply_token_at.isoformat()}
    convo.enqueue(db, "line_send", {"message_id": msg.id, **token})
    if data.close_after:
        convo.set_status(db, conv, "closed", user, f"{user.display_name} 回覆後結案")
    audit(db, user, "message.send", "conversation", conv.id)
    db.commit()
    wake()
    return {"ok": True, "message": _msg_row(msg)}


@router.post("/conversations/{conv_id}/takeover")
def takeover(conv_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    convo.assign(db, conv, user.id, user, f"{user.display_name} 介入處理")
    conv.status = "human"
    conv.ai_paused = True
    conv.unread_count = 0
    db.commit()
    return {"ok": True}


class AssignIn(BaseModel):
    user_id: Optional[str] = None
    note: Optional[str] = None


@router.post("/conversations/{conv_id}/assign")
def assign_conv(conv_id: str, data: AssignIn, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    if conv.assignee_id and conv.assignee_id != user.id and user.role == "agent":
        raise HTTPException(403, "這個對話在別人手上，請由主管移轉")
    if data.user_id:
        target = db.get(User, data.user_id)
        if not target or not target.is_active:
            raise HTTPException(400, "找不到該使用者")
        verb = "移轉給" if conv.assignee_id else "指派給"
        convo.assign(db, conv, target.id, user, f"{user.display_name} {verb} {target.display_name}" + (f"：{data.note}" if data.note else ""))
        conv.status = "human"
        conv.ai_paused = True
    else:
        conv.assignee_id = None
        convo.set_status(db, conv, "pending", user, f"{user.display_name} 釋放回待人工佇列")
    db.commit()
    return {"ok": True}


@router.post("/conversations/{conv_id}/resume-ai")
def resume_ai(conv_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    convo.set_status(db, conv, "ai", user, f"{user.display_name} 交回 AI 處理")
    conv.needs_review = False
    db.commit()
    return {"ok": True}


class CloseIn(BaseModel):
    reason: Optional[str] = None


@router.post("/conversations/{conv_id}/close")
def close_conv(conv_id: str, data: CloseIn, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    conv.close_reason = data.reason
    convo.set_status(db, conv, "closed", user, f"{user.display_name} 結案" + (f"：{data.reason}" if data.reason else ""))
    db.commit()
    return {"ok": True}


@router.post("/conversations/{conv_id}/reopen")
def reopen_conv(conv_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    cust = db.get(Customer, conv.customer_id)
    if convo.get_open_conversation(db, cust):
        raise HTTPException(400, "這位客人已有進行中的對話")
    convo.set_status(db, conv, "human", user, f"{user.display_name} 重新開啟")
    conv.closed_at = None
    conv.assignee_id = user.id
    db.commit()
    return {"ok": True}


@router.post("/conversations/{conv_id}/read")
def mark_read(conv_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    conv.unread_count = 0
    db.commit()
    return {"ok": True}


@router.post("/conversations/{conv_id}/review-ok")
def review_ok(conv_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    conv.needs_review = False
    audit(db, user, "conv.review_ok", "conversation", conv.id)
    db.commit()
    return {"ok": True}


class PriorityIn(BaseModel):
    priority: int


@router.post("/conversations/{conv_id}/priority")
def set_priority(conv_id: str, data: PriorityIn, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    conv.priority = data.priority
    db.commit()
    return {"ok": True}


@router.post("/conversations/{conv_id}/draft")
def request_draft(conv_id: str, db: Session = Depends(get_db), user=Depends(require_user)):
    """請 AI 重新產生一份草稿（不會自動送出）"""
    conv = _get_conv(db, conv_id, user)
    last_cust = (db.query(Message).filter(Message.conversation_id == conv.id, Message.role == "customer")
                 .order_by(Message.created_at.desc()).first())
    if not last_cust:
        raise HTTPException(400, "客人尚未傳訊息")
    convo.enqueue(db, "ai_draft", {"message_id": last_cust.id, "conversation_id": conv.id, "account_id": conv.account_id})
    db.commit()
    wake()
    return {"ok": True}


class RateIn(BaseModel):
    good: bool
    note: Optional[str] = None


@router.post("/messages/{msg_id}/rate")
def rate_message(msg_id: str, data: RateIn, db: Session = Depends(get_db), user=Depends(require_user)):
    m = db.get(Message, msg_id)
    if not m or m.role not in ("ai", "ai_draft"):
        raise HTTPException(404)
    conv = _get_conv(db, m.conversation_id, user)
    last_cust = (db.query(Message).filter(Message.conversation_id == conv.id, Message.role == "customer",
                                          Message.created_at < m.created_at).order_by(Message.created_at.desc()).first())
    db.add(LearningRecord(account_id=conv.account_id, conversation_id=conv.id, message_id=m.id, intent=conv.intent,
                          customer_text=last_cust.content if last_cust else None, ai_draft=m.content,
                          human_final=data.note, kind="rated_good" if data.good else "rated_bad", agent_id=user.id))
    db.commit()
    return {"ok": True}


# ---------- 客人 ----------

class CustomerIn(BaseModel):
    notes: Optional[str] = None
    phone: Optional[str] = None
    tags: Optional[list] = None
    person_key: Optional[str] = None
    display_name: Optional[str] = None


@router.patch("/customers/{cust_id}")
def update_customer(cust_id: str, data: CustomerIn, db: Session = Depends(get_db), user=Depends(require_user)):
    c = db.get(Customer, cust_id)
    if not c:
        raise HTTPException(404)
    for k, v in data.dict(exclude_unset=True).items():
        if k == "tags":
            c.tags = JSONText.dump(v or [])
        elif v is not None:
            setattr(c, k, v)
    db.commit()
    return {"ok": True}


# ---------- 案件 ----------

@router.get("/cases")
def list_cases(status: Optional[str] = None, account_id: Optional[str] = None, db: Session = Depends(get_db), user=Depends(require_user)):
    q = db.query(Case).filter(Case.account_id.in_(_accessible_account_ids(db, user)))
    if status:
        q = q.filter(Case.status.in_(status.split(",")))
    if account_id:
        q = q.filter(Case.account_id == account_id)
    rows = []
    cust_map = {c.id: c for c in db.query(Customer).all()}
    acc_map = {a.id: a.name for a in db.query(Account).all()}
    for c in q.order_by(Case.updated_at.desc()).limit(300).all():
        r = _case_row(c, db)
        cust = cust_map.get(c.customer_id)
        r["customer_name"] = (cust.display_name if cust else None) or "客人"
        r["account_name"] = acc_map.get(c.account_id, "")
        rows.append(r)
    counts = dict(db.query(Case.status, func.count(Case.id)).filter(Case.account_id.in_(_accessible_account_ids(db, user))).group_by(Case.status).all())
    return {"items": rows, "counts": counts}


class CaseIn(BaseModel):
    fields: Optional[dict] = None
    status: Optional[str] = None
    decision: Optional[str] = None
    case_type: Optional[str] = None


@router.post("/cases/{case_id}")
def update_case(case_id: str, data: CaseIn, db: Session = Depends(get_db), user=Depends(require_user)):
    c = db.get(Case, case_id)
    if not c:
        raise HTTPException(404)
    if data.fields is not None:
        f = JSONText.load(c.fields, {})
        f.update({k: v for k, v in data.fields.items()})
        c.fields = JSONText.dump(f)
    if data.case_type:
        c.case_type = data.case_type
    if data.decision is not None:
        c.decision = data.decision
    if data.status:
        c.status = data.status
        if data.status in ("done", "cancelled"):
            c.closed_at = datetime.utcnow()
    c.handler_id = user.id
    c.form_text = build_form_text(db, c)
    audit(db, user, "case.update", "case", c.id, data.dict(exclude_unset=True))
    db.commit()
    return {"ok": True, "case": _case_row(c, db)}


@router.post("/conversations/{conv_id}/cases")
def create_case(conv_id: str, data: CaseIn, db: Session = Depends(get_db), user=Depends(require_user)):
    conv = _get_conv(db, conv_id, user)
    c = Case(account_id=conv.account_id, conversation_id=conv.id, customer_id=conv.customer_id,
             case_type=data.case_type or "other", status=data.status or "clarifying",
             fields=JSONText.dump(data.fields or {}), handler_id=user.id)
    db.add(c)
    db.flush()
    c.form_text = build_form_text(db, c, conv)
    convo.add_system_message(db, conv, f"{user.display_name} 手動建立案件：{CASE_TYPE_LABELS.get(c.case_type, c.case_type)}")
    db.commit()
    return {"ok": True, "case": _case_row(c, db)}


# ---------- 知識庫 ----------

class KnowledgeIn(BaseModel):
    topic: str
    content: str
    account_id: Optional[str] = None
    visibility: str = "public"
    kind: str = "fact"
    intent: Optional[str] = None
    valid_until: Optional[str] = None
    is_active: Optional[bool] = True


def _kn_row(n: KnowledgeNote):
    return {"id": n.id, "topic": n.topic, "content": n.content, "account_id": n.account_id, "visibility": n.visibility,
            "kind": n.kind, "intent": n.intent, "source": n.source, "valid_until": _iso(n.valid_until),
            "is_active": n.is_active, "created_by": n.created_by, "updated_at": _iso(n.updated_at)}


@router.get("/knowledge")
def list_knowledge(q: Optional[str] = None, account_id: Optional[str] = None, kind: Optional[str] = None,
                   include_inactive: bool = False, db: Session = Depends(get_db), user=Depends(require_user)):
    qry = db.query(KnowledgeNote)
    if not include_inactive:
        qry = qry.filter(KnowledgeNote.is_active == True)  # noqa
    if account_id:
        qry = qry.filter(or_(KnowledgeNote.account_id == account_id, KnowledgeNote.account_id == None, KnowledgeNote.account_id == ""))  # noqa
    if kind:
        qry = qry.filter(KnowledgeNote.kind == kind)
    if q:
        like = f"%{q}%"
        qry = qry.filter(or_(KnowledgeNote.topic.like(like), KnowledgeNote.content.like(like)))
    return {"items": [_kn_row(n) for n in qry.order_by(KnowledgeNote.updated_at.desc()).limit(300).all()],
            "intents": intents_list(db)}


@router.post("/knowledge")
def create_knowledge(data: KnowledgeIn, db: Session = Depends(get_db), user=Depends(require_user)):
    n = KnowledgeNote(topic=data.topic.strip(), content=data.content.strip(), account_id=data.account_id or None,
                      visibility=data.visibility, kind=data.kind, intent=data.intent, created_by=user.display_name,
                      valid_until=datetime.fromisoformat(data.valid_until) if data.valid_until else None)
    db.add(n)
    audit(db, user, "knowledge.create", "knowledge", None, {"topic": n.topic})
    db.commit()
    return {"ok": True, "item": _kn_row(n)}


@router.put("/knowledge/{note_id}")
def update_knowledge(note_id: str, data: KnowledgeIn, db: Session = Depends(get_db), user=Depends(require_user)):
    n = db.get(KnowledgeNote, note_id)
    if not n:
        raise HTTPException(404)
    n.topic, n.content, n.visibility, n.kind, n.intent = data.topic.strip(), data.content.strip(), data.visibility, data.kind, data.intent
    n.account_id = data.account_id or None
    n.valid_until = datetime.fromisoformat(data.valid_until) if data.valid_until else None
    if data.is_active is not None:
        n.is_active = data.is_active
    audit(db, user, "knowledge.update", "knowledge", n.id, {"topic": n.topic})
    db.commit()
    return {"ok": True, "item": _kn_row(n)}


@router.delete("/knowledge/{note_id}")
def delete_knowledge(note_id: str, db: Session = Depends(get_db), user=Depends(require_manager)):
    n = db.get(KnowledgeNote, note_id)
    if n:
        n.is_active = False
        audit(db, user, "knowledge.disable", "knowledge", n.id, {"topic": n.topic})
        db.commit()
    return {"ok": True}


# ---------- 回覆範本 ----------

class TemplateIn(BaseModel):
    title: str
    content: str
    account_id: Optional[str] = None
    shortcut: Optional[str] = None


@router.get("/templates")
def list_templates(db: Session = Depends(get_db), user=Depends(require_user)):
    rows = db.query(ReplyTemplate).order_by(ReplyTemplate.sort_order, ReplyTemplate.title).all()
    return {"items": [{"id": t.id, "title": t.title, "content": t.content, "account_id": t.account_id, "shortcut": t.shortcut} for t in rows]}


@router.post("/templates")
def create_template(data: TemplateIn, db: Session = Depends(get_db), user=Depends(require_user)):
    t = ReplyTemplate(title=data.title, content=data.content, account_id=data.account_id or None, shortcut=data.shortcut)
    db.add(t)
    db.commit()
    return {"ok": True, "id": t.id}


@router.put("/templates/{tid}")
def update_template(tid: str, data: TemplateIn, db: Session = Depends(get_db), user=Depends(require_user)):
    t = db.get(ReplyTemplate, tid)
    if not t:
        raise HTTPException(404)
    t.title, t.content, t.account_id, t.shortcut = data.title, data.content, data.account_id or None, data.shortcut
    db.commit()
    return {"ok": True}


@router.delete("/templates/{tid}")
def delete_template(tid: str, db: Session = Depends(get_db), user=Depends(require_user)):
    db.query(ReplyTemplate).filter(ReplyTemplate.id == tid).delete()
    db.commit()
    return {"ok": True}


# ---------- 學習 ----------

@router.get("/learning")
def list_learning(reviewed: Optional[int] = 0, kind: Optional[str] = None, account_id: Optional[str] = None,
                  db: Session = Depends(get_db), user=Depends(require_user)):
    q = db.query(LearningRecord)
    if reviewed is not None:
        q = q.filter(LearningRecord.reviewed == bool(reviewed))
    if kind:
        q = q.filter(LearningRecord.kind.in_(kind.split(",")))
    if account_id:
        q = q.filter(LearningRecord.account_id == account_id)
    users = {u.id: u.display_name for u in db.query(User).all()}
    accs = {a.id: a.name for a in db.query(Account).all()}
    rows = q.order_by(LearningRecord.created_at.desc()).limit(200).all()
    return {"items": [{
        "id": r.id, "account": accs.get(r.account_id), "conversation_id": r.conversation_id, "intent": r.intent,
        "customer_text": r.customer_text, "ai_draft": r.ai_draft, "human_final": r.human_final, "kind": r.kind,
        "customer_signal": r.customer_signal, "reviewed": r.reviewed, "agent": users.get(r.agent_id),
        "promoted_note_id": r.promoted_note_id, "created_at": _iso(r.created_at)} for r in rows],
        "pending_count": db.query(LearningRecord).filter(LearningRecord.reviewed == False).count()}  # noqa


class PromoteIn(BaseModel):
    topic: str
    content: str
    kind: str = "example"
    visibility: str = "public"
    intent: Optional[str] = None
    account_id: Optional[str] = None


@router.post("/learning/{rid}/promote")
def promote_learning(rid: str, data: PromoteIn, db: Session = Depends(get_db), user=Depends(require_manager)):
    r = db.get(LearningRecord, rid)
    if not r:
        raise HTTPException(404)
    n = KnowledgeNote(topic=data.topic, content=data.content, kind=data.kind, visibility=data.visibility,
                      intent=data.intent or r.intent, account_id=data.account_id or r.account_id, source="learning",
                      created_by=user.display_name)
    db.add(n)
    db.flush()
    r.reviewed = True
    r.promoted_note_id = n.id
    audit(db, user, "learning.promote", "learning", r.id, {"note_id": n.id})
    db.commit()
    return {"ok": True, "note": _kn_row(n)}


@router.post("/learning/{rid}/dismiss")
def dismiss_learning(rid: str, db: Session = Depends(get_db), user=Depends(require_manager)):
    r = db.get(LearningRecord, rid)
    if r:
        r.reviewed = True
        db.commit()
    return {"ok": True}


@router.post("/learning/review-all")
def review_all_learning(db: Session = Depends(get_db), user=Depends(require_manager)):
    db.query(LearningRecord).filter(LearningRecord.reviewed == False).update({"reviewed": True})  # noqa
    db.commit()
    return {"ok": True}


# ---------- 使用者（指派用） ----------

@router.get("/users")
def list_users(db: Session = Depends(get_db), user=Depends(require_user)):
    rows = db.query(User).filter(User.is_active == True).order_by(User.role.desc(), User.display_name).all()  # noqa
    loads = dict(db.query(Conversation.assignee_id, func.count(Conversation.id))
                 .filter(Conversation.status == "human").group_by(Conversation.assignee_id).all())
    return {"items": [dict(public_user(u), load=loads.get(u.id, 0)) for u in rows]}


# ---------- 儀表板 ----------

@router.get("/dashboard")
def dashboard(days: int = 7, db: Session = Depends(get_db), user=Depends(require_user)):
    acc_ids = _accessible_account_ids(db, user)
    since = datetime.utcnow() - timedelta(days=days)
    today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(hours=8)  # 台灣今日 00:00（UTC）
    accs = {a.id: a for a in db.query(Account).all()}
    convs = db.query(Conversation).filter(Conversation.account_id.in_(acc_ids), Conversation.created_at >= since).all()
    msgs_ai = db.query(Message).join(Conversation, Message.conversation_id == Conversation.id).filter(
        Conversation.account_id.in_(acc_ids), Message.created_at >= since, Message.role.in_(["ai", "agent", "ai_draft"])).all()
    lrs = db.query(LearningRecord).filter(LearningRecord.created_at >= since, LearningRecord.account_id.in_(acc_ids)).all()

    def pct(a, b):
        return round(100 * a / b, 1) if b else 0

    ai_sent = sum(1 for m in msgs_ai if m.role == "ai" and (m.ai_meta or "") != '{"off_hours": true}')
    agent_sent = sum(1 for m in msgs_ai if m.role == "agent")
    drafts = sum(1 for m in msgs_ai if m.role == "ai_draft")
    accepted = sum(1 for r in lrs if r.kind == "accepted")
    edited = sum(1 for r in lrs if r.kind == "edited")
    frs = [c.first_response_seconds for c in convs if c.first_response_seconds is not None]

    by_intent = {}
    for c in convs:
        k = c.intent or "未判斷"
        by_intent.setdefault(k, {"count": 0, "human": 0})
        by_intent[k]["count"] += 1
        if c.human_touched:
            by_intent[k]["human"] += 1

    by_account = {}
    for c in convs:
        a = accs.get(c.account_id)
        k = a.name if a else "?"
        by_account.setdefault(k, {"count": 0, "open": 0, "human": 0})
        by_account[k]["count"] += 1
        if c.status != "closed":
            by_account[k]["open"] += 1
        if c.human_touched:
            by_account[k]["human"] += 1

    users = {u.id: u.display_name for u in db.query(User).all()}
    by_agent = {}
    for m in msgs_ai:
        if m.role == "agent":
            k = users.get(m.sender_user_id, "?")
            by_agent[k] = by_agent.get(k, 0) + 1

    per_day = {}
    for c in convs:
        d = (c.created_at + timedelta(hours=8)).strftime("%m-%d")
        per_day.setdefault(d, {"total": 0, "human": 0})
        per_day[d]["total"] += 1
        if c.human_touched:
            per_day[d]["human"] += 1

    usage = db.query(func.coalesce(func.sum(AiUsage.input_tokens), 0), func.coalesce(func.sum(AiUsage.output_tokens), 0),
                     func.coalesce(func.sum(AiUsage.calls), 0)).filter(AiUsage.created_at >= since).first()
    today_usage = db.query(func.coalesce(func.sum(AiUsage.input_tokens + AiUsage.output_tokens), 0)).filter(
        AiUsage.day == datetime.utcnow().strftime("%Y-%m-%d")).scalar()

    open_now = db.query(Conversation.status, func.count(Conversation.id)).filter(
        Conversation.account_id.in_(acc_ids), Conversation.status != "closed").group_by(Conversation.status).all()
    waiting = db.query(Conversation).filter(Conversation.account_id.in_(acc_ids), Conversation.waiting_since != None,  # noqa
                                           Conversation.status != "closed").all()
    sla = int(get_setting(db, "sla_warning_minutes") or 10)
    overdue = sum(1 for c in waiting if (datetime.utcnow() - c.waiting_since).total_seconds() > sla * 60)

    return {
        "days": days,
        "totals": {
            "conversations": len(convs),
            "human_touched": sum(1 for c in convs if c.human_touched),
            "ai_only_rate": pct(sum(1 for c in convs if not c.human_touched), len(convs)),
            "ai_sent": ai_sent, "agent_sent": agent_sent, "drafts": drafts,
            "draft_accept_rate": pct(accepted, accepted + edited),
            "draft_edit_rate": pct(edited, accepted + edited),
            "avg_first_response_sec": int(sum(frs) / len(frs)) if frs else None,
            "cases_open": db.query(Case).filter(Case.account_id.in_(acc_ids), Case.status.in_(["clarifying", "review", "processing"])).count(),
            "cases_review": db.query(Case).filter(Case.account_id.in_(acc_ids), Case.status == "review").count(),
            "learning_pending": db.query(LearningRecord).filter(LearningRecord.reviewed == False).count(),  # noqa
            "ai_tokens": int(usage[0] + usage[1]), "ai_calls": int(usage[2]), "ai_tokens_today": int(today_usage or 0),
            "ai_daily_cap": int(get_setting(db, "ai_daily_token_cap") or 0),
        },
        "now": {"open": dict(open_now), "waiting": len(waiting), "overdue": overdue,
                "online_agents": db.query(User).filter(User.online == True, User.is_active == True).count()},  # noqa
        "by_intent": by_intent, "by_account": by_account, "by_agent": by_agent, "per_day": per_day,
    }
